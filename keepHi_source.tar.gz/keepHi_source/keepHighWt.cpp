/****************************************************************************
*
*	keepHighWt.cpp:	Code for retaining edges with high weights. 
*                 
*
*                       Sharlee Climer
*                       June 2011
*
*
****************************************************************************/
  

#include "keepHighWt.h"


int main(int argc, char ** argv)
{
  if (argc != 6)
    fatal("\n\nUsage:\n  keepHi input.gml numNodes numEdgesOrig numEdgesKeep output.gml\n\n"); 

  timer t;
  t.start("Timer started.");

  std::cout << "\nCommand line arguments: \n\t";
  for (int i = 0; i < argc; i++)
        std::cout << argv[i] << " ";
  std::cout << "\n" << std::endl;

  FILE *input;
  FILE *output;
  
  if ((input = fopen(argv[1], "r")) == NULL) 
    fatal("File could not be opened.\n");
    
  FILE *logfile; // log file that records screen output

  char logfileName[200]; // hold name of logfile
  char base[100]; // base for logfile name
  const char logSuffix[] = ".keepHi.log"; // suffix for logfile name

  // determine name for logfile
    for (int i = 0; i < 100; i++) {
      base[i] = argv[5][i]; // copy output file name
      if (base[i] == '\0') {
	if(i < 5)
	  fatal("Expected output file name to have '.gml' suffix");
	
	base[i-4] = '\0'; // set end of string to not include '.gml'
	break;
      }
    }
  
    sprintf(logfileName, "%s%s", base, logSuffix); // string together file name

  if(LOG_FILE) 
    std::cout << "Screen output will be recorded in '" << logfileName <<"'.\n" << std::endl;

  if ((logfile = fopen(logfileName, "w")) == NULL)
      fatal("Log file could not be opened.\n");

  if (LOG_FILE) {
    fprintf(logfile, "\nCommand line arguments: \n\t");
    for (int i = 0; i < argc; i++)
      fprintf(logfile, "%s ", argv[i]);
    fprintf(logfile, "\n\n");
  }

  long long int numNodes = atoi(argv[2]); // number of nodes
  long long int numEdges = atoi(argv[3]); // number of edges in original network
  long long int numKeep = atoi(argv[4]); // number of edges to keep 
  long long int numKept = 0; // actual number of edges kept (may be different due to ties)
  long long int numTies = 0; // number of edges added due to ties
  long long int countNodes = 0; // count nodes for data checking
  long long int countEdges = 0; // count edges for data checking
  char strng[200]; // temporary string storage

  // check validity of values
  if (numNodes < 1)
    fatal("Network must have at least one node");
  if (numEdges < 1)
    fatal("Network must have at least one edge");
  if (numKeep < 1)
    fatal("Must require at least one edge is kept");
  if (numKeep > numEdges)
    fatal("Cannot keep more edges than those that exist in the original network");

  std::cout << "'" << argv[5] << "' will hold new network with " << numKeep << " highest-weight edges." << std::endl;

  long long int min = 1000000000;   // hold min node number
  long long int max = -1000000000;  // hold max node number

  int startOne; // 1 if start node number is 1, 0 if start number is 0

  while (1) { // read in until get to "graph" declaration
    if(feof(input)) fatal("no graph to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "graph", 5) == 0) 
      break; // stop when get to "graph" declaration
  }

  while (1) { // throw away everything until get to "edge" declaration
    if(feof(input)) fatal("no edges to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "id", 2) == 0) { 
      fscanf(input, "%s", strng); // read in id value
      long long int num = atoi(strng);

      if(min > num) min = num; // update minimum node number
      if(max < num) max = num; // update maximum node number
      countNodes++; // one more node found
    }

    if(strncmp(strng, "edge", 4) == 0) 
      break; // stop when read in first "edge"
  }

  if(!QUIET)
    std::cout << "\nNode numbers range from " << min <<" to " << max << "." << std::endl;

  // check number of nodes
  if(countNodes != numNodes)
    fatal("Input file does not contain specified number of nodes.");

  if(!QUIET)
    std::cout << "Reading in graph from '" << argv[1] << "'...\n" << std::endl;

  startOne = min;

  // check validity of values
  if(startOne < 0) fatal("Node numbers can not be negative");

  if ((startOne != 0) && (startOne != 1)) 
    fatal("Smallest node number should be 0 or 1");

  if(max != numNodes - 1 + startOne)
    fatal("Error on maximum node number");

  float *weights; 
  if ((weights = new float[numEdges]) == NULL)
    fatal("memory not allocated");

  // read in edge weights

  while (!feof(input)) { // read edges until reach end of file
    fscanf(input, "%s", strng); // read in string from file

    if(!strncmp(strng, "[", 1) == 0) // check for correct character
      fatal("No '[' after edge declaration");

    fscanf(input, "%s", strng); // read in string from file
    if(!strncmp(strng, "source", 6) == 0) // check for correct character
      fatal("No 'source' declaration");

    fscanf(input, "%s", strng); // read in start node from file
    long long int source = atoi(strng);

    if((source < min) || (source > max))
      fatal("Invalid node number");

    //std::cout << "source: " << idInv[source];

    fscanf(input, "%s", strng); // read in string from file
    if(!strncmp(strng, "target", 6) == 0) // check for correct character
      fatal("No 'target' declaration");

    fscanf(input, "%s", strng); // read in target node from file
    long long int target = atoi(strng);

    if((target < min) || (target > max))
      fatal("Invalid node number");

    //std::cout << ", target: " << idInv[target];

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "weight", 6) == 0) {// check to see if weight specified
      fscanf(input, "%s", strng); // read in string from file
      weights[countEdges] = atof(strng);
      fscanf(input, "%s", strng); // read in string from file
    }
    else
      fatal("All edges must have a weight specified");

    //std::cout << ", weight: " << weight << std::endl;
    
    countEdges++; // count number of edges

    if(countEdges % 10000000 == 0) // message every 10 million edges
      std::cout << countEdges / 1000000 << " million edges read" << std::endl;

    while(!strncmp(strng, "]", 1) == 0) // read in and ignore other properties, if they exist
      fscanf(input, "%s", strng);

    //fprintf(output, "%d\t%d\t%f\n", source, target, weight);

    //if (feof(input)) break; // break as at end of file

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "]", 1) == 0) // check for end of graph
      break;

    if(!strncmp(strng, "edge", 4) == 0) // check for correct character
      fatal("No 'edge' declaration");
  }

  fclose(input);

  if(countEdges != numEdges)
    fatal("Incorrect number of edges in input file");

  if (VERBOSE) {
    std::cout << "Weights of original edges:" << std::endl;
    for (long long int i = 0; i < numEdges; i++)
      std::cout << weights[i] << " ";
    std::cout << "\n" << std::endl;
  }

  std::sort(weights, weights + numEdges); // sort data using quicksort

  if (VERBOSE) {
    std::cout << "Sorted edge weights:" << std::endl;
    for (long long int i = 0; i < numEdges; i++)
      std::cout << weights[i] << " ";
    std::cout << "\n" << std::endl;
  }

  // determine minimum weight edge to keep
  float minWt = weights[numEdges - numKeep]; // values are in increasing order
  minWt -= 0.00001; // capture edges within tolerance level 

  std::cout << "Edges with weight of " << minWt << " or higher will be kept." << std::endl;
  
  if(LOG_FILE)
    fprintf(logfile, "Edges with weight of %f or higher will be kept.\n", minWt);

  // read in old edges and write out ones to keep

  if (((input = fopen(argv[1], "r")) == NULL) || ((output = fopen(argv[5], "w")) == NULL))
    fatal("File could not be opened.\n");

  fprintf(output, "Graph with %d nodes.\ngraph\n[\n",numNodes);

  while (1) { // read in until get to "graph" declaration
    if(feof(input)) fatal("no graph to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "graph", 5) == 0) 
      break; // stop when get to "graph" declaration
  }

  // write out node IDs
  for (long long int i = startOne; i < numNodes+startOne; i++) 
    fprintf(output,"\tnode\n\t[\n\tid %d\n\t]\n", i);

  while (1) { // throw away everything until get to "edge" declaration
    if(feof(input)) fatal("no edges to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "edge", 4) == 0) 
      break; // stop when read in first "edge"
  }

  long long int source; // hold copy of current endpoints
  long long int target; 

  while(!feof(input)) { // read in rest of file
    for (int i = 0; i < 3; i++)
      fscanf(input, "%s", strng); // read in '[ source' and source number

    source = atoi(strng); // source of current edge

    for (int i = 0; i < 2; i++)
      fscanf(input, "%s", strng); // read in 'target' and target number

    target = atoi(strng); // target of current edge

    // check for weight, end of file, or another edge
    fscanf(input, "%s", strng); // read in either 'weight' or ']'
    float weight;

    if(strncmp(strng, "weight", 6) == 0) {// check to see if weight specified
      fscanf(input, "%s", strng); // read in string from file
      weight = atof(strng);
      fscanf(input, "%s", strng); // read in ']' or other properties, if they exist
      while(!strncmp(strng, "]", 1) == 0)
        fscanf(input, "%s", strng); // read in and ignore other properties
    }

    if(feof(input))
      fatal("Input file has missing data or improper format");

    // print out edge if edge is not to be deleted
    if(weight > minWt-TOL) {
      fprintf(output, "\tedge\n\t[\n\tsource %d\n\ttarget %d\n\tweight %f\n\t]\n", source, target, weight);
      numKept++;
      //std::cout << source << ", " << target << std::endl;
    }

    fscanf(input,"%s", strng); // read in either 'edge' or final ']'

    if(strncmp(strng, "]", 1) == 0) // end of file
      break;
  }

  fprintf(output,"]\n"); // write out final bracket

  fclose(input);
  fclose(output);

  std::cout << numKept << " edges written to '" << argv[5] << "' (" << numKept-numKeep << " retained due to ties).\n" << std::endl;
  
  if(LOG_FILE)
    fprintf(logfile, "%d edges written to '%s' (%d retained due to ties).\n\n", numKept, argv[5], numKept-numKeep); 

  t.stop("Timer stopped.");
  std::cout << t << " seconds." << std::endl;
  
  double compTime;
  compTime = t.timeVal();
  
  if (LOG_FILE)
    fprintf(logfile, "%f seconds.\n\n", compTime);
    
  fclose(logfile);

  return 1;
}

