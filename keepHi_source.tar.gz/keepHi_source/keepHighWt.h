// -------------------------------------------------------------------------
// keepHighWt.h -   Header file for retaining high weight edges
//
// written by Sharlee Climer, June 2011
//
// ------------------------------------------------------------------------

#ifndef _KEEPHIGHWT_H
#define _KEEPHIGHWT_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string.h>
#include <algorithm>
#include "timer.h"


const bool QUIET = false;  // set to true to minimize output to screen
const bool VERBOSE = false;  // set to true to maximize output to screen

const bool LOG_FILE = true; // write summary to log file

const float TOL = 0.00000001; // tolerance


inline void warning(const char* p) { fprintf(stderr,"Warning: %s \n",p); }
inline void fatal(const char* string) {fprintf(stderr,"Fatal: %s\n",string);
                                 exit(1); }

#endif
