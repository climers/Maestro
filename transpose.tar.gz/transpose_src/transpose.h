// -------------------------------------------------------------------------
// transpose.h
//
// written by Sharlee Climer, July 2010
//
// ------------------------------------------------------------------------

#ifndef _TRANSPOSE_H
#define _TRANSPOSE_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>

#include "timer.h"

const int NUM_CHARS = 50; // number of characters retained for each string
const int NUM_PARTS = 3; // number of partitions of the data (each read in and written out)

const float TOL = 0.000001; // tolerance

const int QUIET = 1;  // set to one to eliminate output to screen
const int VERBOSE = 0;  // set to one to display maximum output to screen

inline void warning(const char* p) { fprintf(stderr,"Warning: %s \n",p); }
inline void fatal(const char* string) {fprintf(stderr,"\nFatal: %s\n\n",string); exit(1); }

#endif
