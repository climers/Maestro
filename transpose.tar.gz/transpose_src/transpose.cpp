/*   
 *
 *   transpose.cpp 
 *
 *   Program to transpose a table of values
 *
 *   Written by Sharlee Climer
 *   July 2010
 *
 *   Revised to support variable number of characters retained for each string
 *   using NUM_CHARS in header file
 *   January 2012
 *
 *   Revised to reduce platform dependence (iostream.h -> iostream)
 *   November 2015
 *
*/

#include"transpose.h"

int main(int argc, char ** argv)
{
  if (argc != 5)
    fatal("Usage:\n  transpose original.txt numRowsInput numColsInput output.txt"); 

  timer t;
  t.start("Timer started");  


  FILE *input; // input file
  FILE *output; // output file

  std::cout << "Command line arguments: \n\t";
  for (int i = 0; i < argc; i++)
	std::cout << argv[i] << " ";
  std::cout << "\n" << std::endl;

  // check to be sure all files are available
  if ((input = fopen(argv[1], "r")) == NULL)
    fatal("Input file could not be opened");
  if ((output = fopen(argv[4], "w")) == NULL)
    fatal("Output file could not be opened.\n");
 
  int numRows = atoi(argv[2]); // number of rows in input file
  int numCols = atoi(argv[3]); // number of columns in input file
  char strng[200]; // temporary storage of strings

  if (!QUIET) {
    std::cout << "Assuming input file '" << argv[1] << "' has " << numRows << " rows and " << numCols << " columns.\n" << std::endl;

    std::cout << "***Important: " << NUM_CHARS << " characters retained for each string.***" << std::endl;
    std::cout << "This number can be adjusted in the header file.\n" << std::endl;

    std::cout << "The data will be partitioned into " << NUM_PARTS << " segments which will each be read in and written out." << std::endl;
  }

  // check validity of constants
  if((NUM_PARTS < 1) || (NUM_PARTS > numCols))
    fatal("NUM_PARTS is not valid for this dataset");

  int numPerPart = numCols / NUM_PARTS; // number of columns in each partition
  int start, end; // start and end columns for each partition
  int ptr; // pointer for data matrix

  if (!QUIET)
    std::cout << "Number per partition = " << numPerPart << std::endl;

  // find number of columns in remainder
  int numRem = numCols % NUM_PARTS;
  
  if (!QUIET)
    std::cout << "Number in remainder = " << numRem << std::endl;
  
  if (numRem > numPerPart)
    fatal("Remainder is too large. Change NUM_PARTS as needed.");

  // allocate memory 
  char ***data;
  if((data = new char**[numRows]) == NULL)
    fatal("memory not allocated");

  // allocate memory only for one partition at a time
  for (int i = 0; i < numRows; i++) {
    if ((data[i] = new char*[numPerPart]) == NULL)
      fatal("memory not allocated");

    // allocate memory according to the number of characters retained for each string
    // add one extra char for termination symbol
    for (int j = 0; j < numPerPart; j++) {
      if ((data[i][j] = new char[NUM_CHARS+1]) == NULL)
	fatal("memory not allocated");
    }
  }

  // read in data for each partition (remainder will be handled later)
  for (int i = 0; i < NUM_PARTS; i++) {
    if (!QUIET)
      std::cout << "Transposing partition " << i+1 << "..." << std::endl;

    start = i * numPerPart; // begining of current partition
    end = (i+1) * numPerPart - 1; // end of current partition

    // read in entire dataset for each partition
    for (int row = 0; row < numRows; row++) {
      ptr = 0; // set pointer to start of the row

      for (int col = 0; col < numCols; col++) {
	if (feof(input))
	  fatal("Missing data in input file.");
	fscanf(input, "%s", strng);
	
	if((col >= start) && (col <= end)) { // copy if in range
	  // copy appropriate number of characters into memory
	  for (int k = 0; k < NUM_CHARS; k++)
	    data[row][ptr][k] = strng[k];
	  
	  // add termination symbol
	  data[row][ptr][NUM_CHARS] = '\0';

	  // increment pointer to next string
	  ptr++;
	}
      }
    }
    
    // check to see if reached end of file
    if (!feof(input)) {
      fscanf(input, "%s", strng);
      if (!feof(input))
	fatal ("Extra data in input file");
    }

    // rewind to beginning of file for next read
    rewind(input);
    
    // write out transposed data
    for (int i = 0; i < numPerPart; i++) {
      for (int j = 0; j < numRows; j++) {
	      fprintf(output, "%s", data[j][i]);
        if (j != numRows-1)  // don't print tab for last column
          fprintf(output, "\t");   
      }
      fprintf(output, "\n");
    } 
  }

  // read in and write out remainder of file
    start = end + 1; // begining of remainder
    end = numCols - 1; // end of remainder

    // read in entire dataset to get remainder columns
    for (int row = 0; row < numRows; row++) {
      ptr = 0; // set pointer to start of the row

      for (int col = 0; col < numCols; col++) {
	if (feof(input))
	  fatal("Missing data in input file.");
	fscanf(input, "%s", strng);
	
	if((col >= start) && (col <= end)) { // copy if in range
	  // copy appropriate number of characters into memory
	  for (int k = 0; k < NUM_CHARS; k++)
	    data[row][ptr][k] = strng[k];
	  
	  // add termination symbol
	  data[row][ptr][NUM_CHARS] = '\0';

	  // increment pointer to next string
	  ptr++;
	}
      }
    }
    
    // check to see if reached end of file
    if (!feof(input)) {
      fscanf(input, "%s", strng);
      if (!feof(input))
	fatal ("Extra data in input file");
    }
    
    // write out transposed data
    for (int i = 0; i < numRem; i++) {
      for (int j = 0; j < numRows; j++) {
	      fprintf(output, "%s", data[j][i]);
        if (j != numRows-1)  // don't print tab for last column
          fprintf(output, "\t");
      }
      fprintf(output, "\n");
    } 

  if (!QUIET)
    std::cout << "Transposed table has been written to '" << argv[4] << "'.\n" << std::endl;

  fclose(input);
  fclose(output);

  t.stop("Timer stopped");
  std::cout << t << " seconds\n" << std::endl;

  return 1;
}


