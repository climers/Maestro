Graph with 8 nodes. 
graph
[
	node 
	[
	id 1 
	]
	node 
	[
	id 2 
	]
	node 
	[
	id 3 
	]
	node 
	[
	id 4 
	]
	node 
	[
	id 5 
	]
	node 
	[
	id 6 
	]
	node 
	[
	id 7 
	]
	node 
	[
	id 8 
	]
	edge
	[
	source 5
	target 6
	weight 0.56
	]
	edge
	[
	source 5
	target 7
	weight 0.57
	]
	edge
	[
	source 5
	target 4
	weight 0.45
	]
	edge
	[
	source 6
	target 7
	weight 0.67
	]
	edge
	[
	source 6
	target 4
	weight 0.46
	]
	edge
	[
	source 7
	target 4
	weight 0.47
	]
]
