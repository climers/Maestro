/****************************************************************************
*
*	rmSingle.cpp:	Code for removing singleton nodes from .gml file
*                       from components.
*
*                       Sharlee Climer
*                       June 2012
*
*
****************************************************************************/
  

#include "rmSingle.h"
#include "network.h"

using namespace std;


int main(int argc, char ** argv)
{
  if (argc != 5)
    fatal("Usage:\n  rmSingle input.gml numNodes numEdges output.gml"); 

  timer t;
  t.start("Timer started.");

  cout << "\nCommand line arguments: \n\t";
  for (int i = 0; i < argc; i++)
        cout << argv[i] << " ";
  cout << "\n" << endl;

  cout << "Singleton nodes in '" << argv[1] << "' will be removed and new network will be written to '" << argv[4] << "'...\n" << endl;

  FILE *input;
  FILE *output;
  
  if ((input = fopen(argv[1], "r")) == NULL) 
    fatal("File could not be opened.\n");

  int numNodes = atoi(argv[2]); // number of nodes
  int numEdges = atoi(argv[3]); // number of edges
  int countNodes = 0; // count nodes for data checking
  int countEdges = 0; // count edges for data checking
  char strng[200]; // temporary string storage

  int min = 1000000000;   // hold min node number
  int max = -1000000000;  // hold max node number

  int startOne; // 1 if start node number is 1, 0 if start number is 0

  while (1) { // read in until get to "graph" declaration
    if(feof(input)) fatal("no graph to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "graph", 5) == 0) 
      break; // stop when get to "graph" declaration
  }

  while (1) { // throw away everything until get to "edge" declaration
    if(feof(input)) fatal("no edges to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "id", 2) == 0) { 
      fscanf(input, "%s", strng); // read in id value
      int num = atoi(strng);

      if(min > num) min = num; // update minimum node number
      if(max < num) max = num; // update maximum node number
      countNodes++; // one more node found
    }

    if(strncmp(strng, "edge", 4) == 0) 
      break; // stop when read in first "edge"
  }

  cout << "\nNode numbers range from " << min <<" to " << max << "." << endl;

  // check number of nodes
  if(countNodes != numNodes)
    fatal("Input file does not contain specified number of nodes.");

  cout << "Reading in graph from " << argv[1] << "...\n" << endl;

  startOne = min;

  // check validity of values
  if(startOne < 0) fatal("Node numbers can not be negative");

  if ((startOne != 0) && (startOne != 1)) 
    fatal("Smallest node number should be 0 or 1");

  if(max != numNodes - 1 + startOne)
    fatal("Error on maximum node number");

  // create network with numNodes vertices
  Network sparseNet(numNodes+startOne, DIRECTED); // if DIRECTED = 0, undirected
  int dupEdges = 0; // record number of duplicate edges

  while (!feof(input)) { // read edges until reach end of file
    fscanf(input, "%s", strng); // read in string from file

    if(!strncmp(strng, "[", 1) == 0) // check for correct character
      fatal("No '[' after edge declaration");

    fscanf(input, "%s", strng); // read in string from file
    if(!strncmp(strng, "source", 6) == 0) // check for correct character
      fatal("No 'source' declaration");

    fscanf(input, "%s", strng); // read in start node from file
    int source = atoi(strng);

    if((source < min) || (source > max))
      fatal("Invalid node number");

    //cout << "source: " << idInv[source];

    fscanf(input, "%s", strng); // read in string from file
    if(!strncmp(strng, "target", 6) == 0) // check for correct character
      fatal("No 'target' declaration");

    fscanf(input, "%s", strng); // read in target node from file
    int target = atoi(strng);

    if((target < min) || (target > max))
      fatal("Invalid node number");

    //cout << ", target: " << idInv[target];

    fscanf(input, "%s", strng); // read in string from file

    float weight = 1.0;
    if(strncmp(strng, "weight", 6) == 0) {// check to see if weight specified
      fscanf(input, "%s", strng); // read in string from file
      weight = atof(strng);
      fscanf(input, "%s", strng); // read in string from file
    }

    //cout << ", weight: " << weight << endl;
    
    if(!sparseNet.addEdge(source,target,weight))
	  dupEdges++;
      //warning("Duplicate edge in input");
    
    else
      countEdges++; // count number of edges

	if(countEdges % 10000000 == 0) // message every 10 million edges
	  cout << countEdges / 1000000 << " million edges read" << endl;

    if(!strncmp(strng, "]", 1) == 0) // check for correct character
      fatal("No ']' after edge declaration");

    //fprintf(output, "%d\t%d\t%f\n", source, target, weight);

    //if (feof(input)) break; // break as at end of file

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "]", 1) == 0) // check for end of graph
      break;

    if(!strncmp(strng, "edge", 4) == 0) // check for correct character
      fatal("No 'edge' declaration");
  }

  fclose(input);

  if(countEdges != numEdges)
    fatal("Incorrect number of edges in input file");

  // allocate memory to store nodes which will have edges removed

  int *rmNode; 
  if ((rmNode = new int[numNodes+startOne]) == NULL)
    fatal("memory not allocated");

  for (int i = 0; i <= numNodes+startOne; i++)
    rmNode[i] = -1; // initialize values to -1

  // find nodes with degree = zero
  long int numSingle = 0; // number of nodes with edges removed
  long int numKeep = 0; // number of nodes to keep

  int maxDegree = 0; // maximum degree of any node
  int maxDegreeNode = -1; // number of node with max degree

  for (int i = startOne; i < numNodes+startOne; i++) {
    int degree = sparseNet.getDegree(i);
    if (degree == 0) {
      //cout << i << endl;
      numSingle++; 
    }

    if (degree > 0) { // keep this node
      numKeep++;
      rmNode[i] = numKeep; // assign new node number, starting with 1
    }

    if(degree > maxDegree) {
      maxDegree = degree;
      maxDegreeNode = i;
    }
  }
  
  cout << "\n" << numSingle << " singleton nodes will be removed." << endl;
  cout << "Node " << maxDegreeNode << " has highest degree: " << maxDegree << ".\n" << endl;

  // read in original edges and write out with new node numbers

  if (((input = fopen(argv[1], "r")) == NULL) || ((output = fopen(argv[4], "w")) == NULL))
    fatal("File could not be opened.\n");

  fprintf(output, "Graph with %d nodes.\ngraph\n[\n",numNodes-numSingle);

  while (1) { // read in until get to "graph" declaration
    if(feof(input)) fatal("no graph to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "graph", 5) == 0) 
      break; // stop when get to "graph" declaration
  }

  for (int i = startOne; i < numNodes+startOne-numSingle; i++) 
    fprintf(output,"\tnode\n\t[\n\tid %d\n\t]\n", i);

  while (1) { // throw away everything until get to "edge" declaration
    if(feof(input)) fatal("no edges to read in input file");

    fscanf(input, "%s", strng); // read in string from file

    if(strncmp(strng, "edge", 4) == 0) 
      break; // stop when read in first "edge"
  }

  int source; // hold copy of current endpoints
  int target; 
  int numKept = 0; // number of edges kept

  while(!feof(input)) { // read in rest of file
    for (int i = 0; i < 3; i++)
      fscanf(input, "%s", strng); // read in '[ source' and source number

    source = atoi(strng); // source of current edge

    for (int i = 0; i < 2; i++)
      fscanf(input, "%s", strng); // read in 'target' and target number

    target = atoi(strng); // target of current edge

    // check for weight, end of file, or another edge
    fscanf(input, "%s", strng); // read in either 'weight' or ']'
    float weight = 1.0;

    if(strncmp(strng, "weight", 6) == 0) {// check to see if weight specified
      fscanf(input, "%s", strng); // read in string from file
      weight = atof(strng);
      fscanf(input, "%s", strng); // read in ']' from file
    }

    if(feof(input))
      fatal("Input file has missing data or improper format");

    // print out edge with new node numbers
    //    if(!rmNode[source] && !rmNode[target]) 

    fprintf(output, "\tedge\n\t[\n\tsource %d\n\ttarget %d\n\tweight %f\n\t]\n", rmNode[source], rmNode[target], weight);
    numKept++;
    //cout << source << ", " << target << endl;

    // check validity of endpoints
    if((rmNode[source] < 0) || (rmNode[target] < 0))
      fatal("Node defined as a singleton has an incident edge");

    fscanf(input,"%s", strng); // read in either 'edge' or final ']'

    if(strncmp(strng, "]", 1) == 0) // end of file
      break;
  }

  fprintf(output,"]\n"); // write out final bracket

  cout << numKept << " edges written to " << argv[4] << "." << endl;

  fclose(input);
  fclose(output);

  if (PRINT_NUMS == 1) { // print out original node numbers to 'origNum.txt'

    if ((output = fopen("rmSingleOrigNum.txt", "w")) == NULL)
      fatal("'origNum.txt' file could not be opened.\n");

    fprintf(output, "New_Node_Num\tOrig_Node_Num\n");

    for (int i = startOne; i < numNodes+startOne; i++) 
      if (rmNode[i] > 0) // print if not a singleton node
	fprintf(output, "%d\t%d\n", rmNode[i], i);

    fclose(output);

    cout << "Original node numbers are printed to 'rmSingleOrigNum.txt'.\n" << endl;
  }

  t.stop("Timer stopped.");
  cout << t << " seconds." << endl;



  /*
  if(DESCRIPTIVE_OUTPUT)
    fprintf(output, "%s\n", argv[1]);

  int min = 1000000000;   // hold min node number
  int max = -1000000000;  // hold max node number
  char string[50];
  int startOne; // 1 if start node number is 1, 0 if start number is 0

  while (1) { // throw away everything until get to "graph" declaration
    if(feof(input)) fatal("no graph to read in input file");

    fscanf(input, "%s", string); // read in string from file

    if(strncmp(string, "graph", 5) == 0) 
      break; // stop when get to "graph" declaration
  }

  // find number of nodes in graph
  int numNodes = 0; // number of nodes
  int numEdges = 0; // number of edges

  while (1) { // throw away everything until get to "edge" declaration
    if(feof(input)) fatal("no edges to read in input file");

    fscanf(input, "%s", string); // read in string from file

    if(strncmp(string, "id", 2) == 0) { 
      fscanf(input, "%s", string); // read in id value
      int num = atoi(string);

      if(min > num) min = num; // update minimum node number
      if(max < num) max = num; // update maximum node number
      numNodes++; // one more node found
    }

    if(strncmp(string, "edge", 4) == 0) 
      break; // stop when read in first "edge"
  }

  cout << "\nNode numbers range from " << min <<" to " << max << endl
;
  cout << "Reading in graph from " << argv[1] << "...\n" << endl;

  if (DESCRIPTIVE_OUTPUT)
    fprintf(output, "Node numbers range from %d to %d\n\n", min, max);
  fclose(output); 

  startOne = min;
  rewind(input); // start at beginning of input file again

  if(startOne < 0) fatal("Node numbers can not be negative");
  if ((startOne != 0) && (startOne != 1)) 
    warning("Smallest node number should be 0 or 1");

  // record node id numbers
  int ptr = 0; // pointer for filling nodeNumbers array
  int *id; // hold the node IDs as given in input file
  if ((id = new int[numNodes]) == NULL)
    fatal("memory not allocated");

  while (1) { // throw away everything until get to "graph" declaration
    if(feof(input)) fatal("no graph to read in input file");

    fscanf(input, "%s", string); // read in string from file

    if(strncmp(string, "graph", 5) == 0) 
      break; // stop when get to "graph" declaration
  }

  while (1) { // record node id numbers 
    if(feof(input)) fatal("no edges to read in input file");

    fscanf(input, "%s", string); // read in string from file
  
    if(strncmp(string, "id", 2) == 0) { 
      fscanf(input, "%s", string); // read in id value
      int num = atoi(string);

      if((num < min) || (num > max))
	fatal("error while reading in node numbers");

      id[ptr++] = num; // record node id number
      //cout << ptr << ", " << id[ptr-1]<< endl;
    }

    if(strncmp(string, "edge", 4) == 0) 
      break; // stop when read in first "edge"
  }

  if (ptr != numNodes)
    fatal("Error reading in node numbers");

  int *idInv; // invert the ID numbers for easy look-up
  if ((idInv = new int[max+1]) == NULL)
    fatal("memory not allocated");

  //cout << "id: " ;
  for (int i = 0; i < max+1; i++)
    idInv[i] = -1; // initialize values
  for (int i = 0; i < numNodes; i++) {
    //cout << id[i] << " ";
    if(idInv[id[i]] != -1)
      fatal("Error recording index for ID number");
    idInv[id[i]] = i; // record index for given id number
  }
  //cout << endl;

  if (0) {
    cout << "idInv: ";
    for (int i = 0; i < max+1; i++)
      cout << idInv[i] << " ";
    cout << endl;
  }

  // create network with numNodes vertices
  Network sparseNet(numNodes, DIRECTED); // if DIRECTED = 0, undirected
  int dupEdges = 0; // record number of duplicate edges

  while (!feof(input)) { // read edges until reach end of file
    fscanf(input, "%s", string); // read in string from file

    if(!strncmp(string, "[", 1) == 0) // check for correct character
      fatal("No '[' after edge declaration");

    fscanf(input, "%s", string); // read in string from file
    if(!strncmp(string, "source", 6) == 0) // check for correct character
      fatal("No 'source' declaration");

    fscanf(input, "%s", string); // read in start node from file
    int source = atoi(string);

    if((source < min) || (source > max))
      fatal("Invalid node number");

    //cout << "source: " << idInv[source];

    fscanf(input, "%s", string); // read in string from file
    if(!strncmp(string, "target", 6) == 0) // check for correct character
      fatal("No 'target' declaration");

    fscanf(input, "%s", string); // read in target node from file
    int target = atoi(string);

    if((target < min) || (target > max))
      fatal("Invalid node number");

    //cout << ", target: " << idInv[target];

    fscanf(input, "%s", string); // read in string from file

    float weight = 1.0;
    if(strncmp(string, "weight", 6) == 0) {// check to see if weight specified
      fscanf(input, "%s", string); // read in string from file
      weight = atof(string);
      fscanf(input, "%s", string); // read in string from file
    }

    //cout << ", weight: " << weight << endl;
    
    if(!sparseNet.addEdge(idInv[source],idInv[target],weight))
	  dupEdges++;
      //warning("Duplicate edge in input");
    
    else
      numEdges++; // count number of edges

	if(numEdges % 10000000 == 0) // message every 10 million edges
	  cout << numEdges / 1000000 << " million edges read" << endl;

    if(!strncmp(string, "]", 1) == 0) // check for correct character
      fatal("No ']' after edge declaration");

    //fprintf(output, "%d\t%d\t%f\n", source, target, weight);

    if (feof(input)) break; // break is at end of file

    fscanf(input, "%s", string); // read in string from file

    if(strncmp(string, "]", 1) == 0) // check for end of graph
      break;

    if(!strncmp(string, "edge", 4) == 0) // check for correct character
      fatal("No 'edge' declaration");
  }

  //cout << endl;
 
  fclose(input);

  if (sparseNet.getNumEdges() != numEdges)
    fatal("error recording edges in network");

  cout << "\nFinding components and printing them to compX.gml files...\n" << endl;

  sparseNet.bfs(argv[2]);

  cout << numEdges << " edges explored" << endl;
  cout << dupEdges << " duplicate edges not counted in edge count" << endl;
  //if (dupEdges > 0)
  //cout << "Highest edge weight recorded for duplicate edges" << endl;

  t.stop("Timer stopped");
  cout << t << " seconds" << endl;

  if ((output = fopen(argv[2], "a")) == NULL)
    fatal("File could not be opened.\n");
  fprintf(output,"%f\n",t.timeVal());
  fclose(output);

  delete [] id;
  delete [] idInv;
  */

  return 1;
}

