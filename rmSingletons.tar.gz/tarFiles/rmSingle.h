// -------------------------------------------------------------------------
// rmSingle.h -   Header file for removing singleton nodes
//
// written by Sharlee Climer, June 2012
//
// ------------------------------------------------------------------------

#ifndef _RMSINGLE_H
#define _RMSINGLE_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include "timer.h"

const int PRINT_NUMS = 1; // 1 to print original node numbers to 'rmSingleOrigNum.txt'
//const int HIGHDEGREE = 500; // threshold for high degree
//const int ALLELE = 0; // set to 1 for networks with 2 nodes for each gene

const int QUIET = 0;  // set to one to eliminate output to screen
const int VERBOSE = 1;  // set to one to display maximum output to screen
const int DIRECTED = 0; // set to one for directed graph

inline void warning(const char* p) { fprintf(stderr,"Warning: %s \n",p); }
inline void fatal(const char* string) {fprintf(stderr,"Fatal: %s\n",string);
                                 exit(1); }

#endif
