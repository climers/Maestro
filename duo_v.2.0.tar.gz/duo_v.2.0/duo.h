// -------------------------------------------------------------------------
// duo.h -   Header file for finding correlations between pairs of genes
//
// written by Sharlee Climer
//
// ------------------------------------------------------------------------

#ifndef _DUO_H
#define _DUO_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string.h>
#include <algorithm>

#include "timer.h"

const bool QUIET = true;  // set to true to minimize output to screen
const bool VERBOSE = false;  // set to true to maximize output to screen

//const float MIN_THRESH = 0.5; // minimum Duo threshold for printing out an edge

const bool GLOBAL_HI_LO = false; // set to true to compute global high/low thresholds. **If false, be sure to discretize data to -1, 0 , 1 for low, neutral, high values**
const float HI_LO_PERCENT = 0.30; // use if GLOBAL_HI_LO is set to true

const bool PRINT_ID = false; // set to true to print out ID label to gml file (assume ID is in last header column)
const bool PRINT_PERCENT_MISSING = false; // set to true to print out percent missing (for each analyte and each edge) to gml file

// the following is used to validate each edge using permutation trials
const bool VALIDATE = true; // true for validation of each edge by permutation trials
const int NUMRANDTRIALS = 50; // number of permutation trials for validation
const float MAXPERCENT = 0.05; // maximum allowed percentage of permutation trials above Duo value for unpermuted (p-value)

const int MAXNUMEDGES = 100000000; // maximum number of edges to be output
const double TOL = 0.000001; // tolerance
const int STRNG_LENGTH = 200; // number of chars allocated for strings
const bool LOG_FILE = true; // print screen output to logfile

// following used for error checking, can be modified as needed
const float MAX_EXP = 1000000.0; // maximum expression level allowed in input
const float MIN_EXP = -100000.0; // minimum expression level allowed in input
const int MAX_NUM_INDIVIDUALS = 100000; // maximum number of individuals
const int MAX_NUM_GENES = 10000000; // maximum number of genes

// these output information from each trial to the noted files
const bool PRINTNUMEDGES = false; // set to true to print number of edges & overwrite "numEdges.txt"
const bool PRINTNUMEDGESINFO = false; // set to true to append number of edges & info "numEdgesInfo.txt"
const bool APPENDEDGES = false; // set ot true to append edges to "edgeList.txt"

// these should not be changed for this version of the code
const bool FREQ = true; // use frequency information in correlation value
const float FREQWT = 1.5; // weight used for frequency factor (1.5)
const float SCALEFACTOR = 4.0; // scaling factor
const bool PRINTGML = true; // print network to .gml file 
const bool TWONODE = true; // create a network with two nodes for each gene
const bool PRINT_BINS = false; // true if want to print out number of CCC values in each bin
const int NUMBINS = 1000; // number of bins 



inline void warning(const char* p) { fprintf(stderr,"Warning: %s \n",p); }
inline void fatal(const char* string) {fprintf(stderr,"\nFatal: %s\n\n",string); exit(1); }

#endif
