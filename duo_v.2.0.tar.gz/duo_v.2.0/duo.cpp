/****************************************************************************
*
*	duo.cpp:	Code for quantifying correlations between pairs of 
*                       genes for a group of individuals and creating
*                       network in gml format.  
*      
*
*                       Sharlee Climer
*                       February 2020 (rewritten from 2010 version)
*       
*            Made global threshold computation optional (default 0.9, -0.9)
*            June 2020
*                     
*            Added option to print out id labels to gml 
*            Feb 2021
*
****************************************************************************/
  

#include "duo.h"

void checkConstants(); // check validity of constants in 'duo.h'
int compThresh(char *inputFile, int numInd, int numGenes, int numHeadCols, int numHeadRows, float percentHiLo, float *hiLo, char *logfileName); // determine thresholds for high and low expression discretization
long int findEdges(char **data, double **freq, char *outFile, int numInd, int numGenes, char *logfileName, float thresh, char **id, int *numIndNoMiss); // compute and write out edges
int compDuo(float *duo, char *data1, char *data2, double *freq1, double *freq2, int numInd); // compute Duo correlation values for two genes
int validate(float *tempDuo, char *data1, char *data2, double *freq1, double *freq2, int numInd, float duoVal); // validate an edge using permutation trials


int main(int argc, char ** argv)
{
  if (argc != 8)
    fatal("Usage:\n\n   duo input.discretized output.gml numInd numAnalytes numHeaderCols numHeaderRows correlationThreshold\n\n"); 

  timer t;
  t.start("Timer started.");

  std::cout << "\nCommand line arguments: \n\t";
  for (int i = 0; i < argc; i++)
	std::cout << argv[i] << " ";
  std::cout << "\n" << std::endl;

  FILE *input;
  FILE *output;
  FILE *logfile;
  
  char logfileName[200]; // hold name of logfile
  char base[100]; // base for logfile name
  const char logSuffix[] = ".duo.log"; // suffix for logfile name

  // determine name for logfile
  for (int i = 0; i < 100; i++) {
    base[i] = argv[2][i]; // copy output file name
    if (base[i] == '\0') {
	    if(i < 5)
	      fatal("Expected output file name to have at least five characters");
	
      base[i-4] = '\0'; // set end of string to not include '.gml'
	    break;
    }
  }
  
  sprintf(logfileName, "%s%s", base, logSuffix); // string together file name

  if(LOG_FILE) 
    std::cout << "Summary output will be recorded in '" << logfileName <<"'.\n" << std::endl;

  if ((logfile = fopen(logfileName, "w")) == NULL)
      fatal("Log file could not be opened.\n");

  if (LOG_FILE) {
    fprintf(logfile, "\nCommand line arguments: \n\t");
    for (int i = 0; i < argc; i++)
      fprintf(logfile, "%s ", argv[i]);
    fprintf(logfile, "\n\n");
  }

  if ((input = fopen(argv[1], "r")) == NULL)
    fatal("Input file could not be opened.\n");
  if ((output = fopen(argv[2], "w")) == NULL)
      fatal("Output file could not be opened.\n");

  fclose(input); // reopen when ready
  fclose(output); // reopen when ready  

  //if(!TWONODE)
  //fatal("Check results are correct when only one node is output per gene.");
  if (PRINT_BINS)
    fatal("PRINT_BINS feature may have bugs, set value to 0 in 'duo.h'.");

  char strng[STRNG_LENGTH];

  int numInd = atoi(argv[3]); // number of individuals

  int numGenes = atoi(argv[4]);  // number of genes
  int numNodes = 2 * numGenes; // number of nodes
  int numHeadCols = atoi(argv[5]); // number of header columns
  int numHeadRows = atoi(argv[6]); // number of header rows
  float thresh = atof(argv[7]); // duo threshold for printing edges
  
  std::cout << "\n**Important: Assumed rows represent analytes in input file.**\n" << std::endl;

  std::cout << "Assumed " << numHeadRows << " header rows and " << numHeadCols << " header columns in '" << argv[1] << "'." << std::endl;

  if(VERBOSE && TWONODE)
    std::cout << "Each gene will be represented by two nodes in output graph." << std::endl;

  if(VERBOSE && FREQ) 
	std::cout << "Frequencies used in computations with a weight of " << FREQWT << ".\n" << std::endl;

  std::cout << numInd << " individuals and " << numGenes << " analytes." << std::endl;
  std::cout << "Duo minimum threshold of " << thresh << " used." << std::endl;

  if(VALIDATE) {
    std::cout << "Each edge will be validated by running " << NUMRANDTRIALS << " permutation trials." << std::endl;
    std::cout << "Edge will be output only if no more than " << MAXPERCENT * 100.0 << "% of the permutation trials produce a Duo correlation higher than the Duo value for the original data.\n" << std::endl;
  }
 
  if (LOG_FILE) {
    fprintf(logfile, "\n**Important: Assumed rows represent analytes in input file.**\n\nAssumed %d header rows and %d header columns in '%s'.\n", numHeadRows, numHeadCols, argv[1]);
    
    if(VERBOSE && TWONODE)
      fprintf(logfile, "Each gene will be represented by two nodes in output graph.\n");

    if(VERBOSE && FREQ) 
      fprintf(logfile, "Frequencies used in computations with a weight of %0.2f.\n\n", FREQWT);
      
    fprintf(logfile, "%d individuals and %d analytes.\nDuo minimum threshold of %0.2f used.\n" , numInd, numGenes, thresh);  

    if(VALIDATE) {
      fprintf(logfile, "Each edge will be validated by running %d permutation trials.\nEdge will be output only if no more than %0.2f percent of the permutation trials produce a Duo correlation higher than the Duo value for the original data.\n\n", NUMRANDTRIALS, MAXPERCENT * 100.0);
    } 
  }
  
  fclose(logfile);

  if (numInd > MAX_NUM_INDIVIDUALS)
	fatal("Too many individuals.  Fix header file.");
  if (numGenes > MAX_NUM_GENES)
	fatal("Too many analytes.  Fix header file.");
  if ((numInd < 2) || (numGenes < 2))
	fatal("Too few individuals or analytes");

  float hiLo[2]; // array to hold threshold values for high and low expression
  
  if (GLOBAL_HI_LO) { // compute global high/low thresholds using HI_LO_PERCENT
    float percentHiLo = HI_LO_PERCENT; // percentage of values to be considered high or low
  
    // check percentHiLo
    if (percentHiLo > 1.0 - TOL) 
      percentHiLo /= 100.0; // assume user input integer for percentage
    
    if (percentHiLo > 0.6) // (arbitrary cutoff) Any value above 0.5 will result with some values treated as both high and low
      fatal ("Input for 'percentHiLo' is too high.");
    
    if (percentHiLo < 0.001)
      fatal ("Input for 'percentHiLo' is too low.");  
    
    if (percentHiLo > 0.5 + TOL)
      warning ("Some data values will be considered both high and low!");
      
    std::cout << "The highest and lowest " << percentHiLo * 100.0 << "% of values globally will be considered high/low expression." << std::endl;

    int okay = compThresh(argv[1], numInd, numGenes, numHeadCols, numHeadRows, percentHiLo, hiLo, logfileName);
    if (!okay)
      fatal("Error while computing high and low thresholds");
  }
  
  if (!GLOBAL_HI_LO) { // set high/low threshold to 0.9 and -0.9 (assume data was discretized to -1, 0 1)
    hiLo[0] = -0.9;
    hiLo[1] = 0.9;
  }
    
  if ((logfile = fopen(logfileName, "a")) == NULL)
    fatal("Log file could not be opened.\n");

  std::cout << "Expression value considered high if >= " << hiLo[1];
  std::cout << ", and low if <= " << hiLo[0] << "." << std::endl;

  if(LOG_FILE)
    fprintf(logfile, "Expression value considered high if >= %f and low if <= %f.\n", hiLo[1], hiLo[0]);

  // allocate data array memory
  char **data; // hold expression values: 3=missing, 2=up, 1=none, 0=down regulated 
  if ((data = new char*[numGenes]) == NULL)
    fatal("memory not allocated");
  for (int i = 0; i < numGenes; i++)
    if ((data[i] = new char[numInd]) == NULL)
      fatal("memory not allocated");

  // initialize data values to '3', indicating missing values
  for (int i = 0; i < numGenes; i++)
    for (int j = 0; j < numInd; j++)
      data[i][j] = '3';

  // allocate memory for storing frequency information
  double **freq; // hold frequency values for up- and down-regulated
  if ((freq = new double*[numGenes]) == NULL)
    fatal("memory not allocated");
  for (int i = 0; i < numGenes; i++)
    if ((freq[i] = new double[2]) == NULL)
      fatal("memory not allocated");

  // initialize frequency values to zero
  for (int i = 0; i < numGenes; i++)
    for (int j = 0; j < 2; j++)
      freq[i][j] = 0;

  // allocate memory for number of individuals without missing data (per gene)
  int *numIndNoMiss; 
  if ((numIndNoMiss = new int[numGenes]) == NULL)
    fatal("memory not allocated");

  // initialize values to all individuals
  for (int i = 0; i < numGenes; i++)
    numIndNoMiss[i] = numInd;
    
  // allocate memory for holding analyte ID labels
  char **id; 
  if ((id = new char*[numGenes]) == NULL)
    fatal("memory not allocated");
  for (int i = 0; i < numGenes; i++)
    if ((id[i] = new char[STRNG_LENGTH]) == NULL)
      fatal("memory not allocated");

  // read in header rows
  if ((input = fopen(argv[1], "r")) == NULL)
    fatal("Input file could not be opened.\n");

  for (int i = 0; i < numHeadRows; i++)
    for (int j = 0; j < numHeadCols + numInd; j++)
      fscanf(input, "%s", strng); // read in header rows

  // read in data
  float val; // value read in
  long int numMissing = 0; // count number of missing values
  float maxExpr = MIN_EXP; // initialize maximum expression value
  float minExpr = MAX_EXP; // initialize minimum expression value

  for (int i = 0; i < numGenes; i++) {
    for (int j = 0; j < numHeadCols-1; j++) 
      fscanf(input, "%s", strng); // read in header columns
      
    if(numHeadCols > 0)
      fscanf(input, "%s", id[i]);

    for (int j = 0; j < numInd; j++) {
      if(feof(input))
	      fatal("Input file is missing data");

      fscanf(input, "%s", strng);
      val = atof(strng);

      // check that strng holds a number
      int ascii = (int)strng[0]; // ascii value of first character

      if((ascii < 48) || (ascii > 57)) { // not a digit
	      if((ascii != 45) && (ascii != 46)) { // not a '-' or '.'
	  
	        if(ascii == 78) { // starts with 'N' for missing data
	          if (strncmp(strng, "N", 1) == 0) {
	            numMissing++; // add to count
	            val = MAX_EXP + 1; // set missing values to more than maximum expression 
	            numIndNoMiss[i]--; // one less indiv. with no missing data for this gene
	          }
	          else {
	            std::cout << strng << std::endl;
	            fatal("Invalid expression value in input file");
	          }
	        }
	
	        else {
	          std::cout << strng << std::endl;
	          fatal("Invalid expression value in input file");
	        }
	      }
      }

  if((ascii >= 48) && (ascii <= 57)) { // is a digit
	  if ((val > MAX_EXP) || (val < MIN_EXP)) {
	    std::cout << strng << std::endl;
	    fatal ("Invalid expression value in input data.  \n\tCheck MAX_EXP and MIN_EXP in header file.");
	  }
      }

  if((ascii == 45) || (ascii == 46)) // is a '-' or '.'
	  if ((val > MAX_EXP) || (val < MIN_EXP)) {
	    std::cout << strng << std::endl;
	    fatal ("Invalid expression value in input data.  \n\tCheck MAX_EXP and MIN_EXP in header file.");
	}
      
      // update min and max, if appropriate
      if(val > maxExpr)
	if(val < MAX_EXP + TOL) // not missing value symbol
	  maxExpr = val;

      if(val < minExpr)
	minExpr = val;

      // encode expression in data matrix, if not a missing value
      if (val < MAX_EXP + TOL) {

	if (val > hiLo[1] - TOL) {
	  data[i][j] = '2'; // up-regulated
	  freq[i][0]++; // add another up-reg to frequencies
	  continue;
	}

	if (val < hiLo[0] + TOL) {
	  data[i][j] = '0'; // down-regulated
	  freq[i][1]++; // add another down-reg to frequencies 
	  continue;
	}

	data[i][j] = '1'; // not missing, high, or low
	continue;
      }
    }
  }

  if (0)
    for (int i = 0; i < numGenes; i++)
      std::cout << id[i] << "\n";

  std::cout << "Expression values range from " << minExpr << " to " << maxExpr << ".\n" ;
  std::cout << numMissing << " missing values in input file.\n"; 
  
  if(LOG_FILE)
    fprintf(logfile, "Expression values range from %f to %f.\n%d missing values in input file.\n", minExpr, maxExpr, numMissing);
  
  // check for end of file
  if (!feof(input)){
    fscanf(input, "%s", strng);
    if (!feof(input))
      fatal("Unread data in input file");
  }

  fclose(input); 

  // output number of up- and down-regulated genes in data
  double sum = 0;
  for (int i = 0; i < numGenes; i++)
    sum += freq[i][0]; // add up the up-regulated genes
  std::cout << sum << " high expression values in data." << std::endl;

  if(LOG_FILE)
    fprintf(logfile, "%0.0f high expression values in data.\n", sum);

  sum = 0; 
  for (int i = 0; i < numGenes; i++)
    sum += freq[i][1]; // add up the dn-regulated genes
  std::cout << sum << " low expression values in data." << std::endl;
  
  if(LOG_FILE)
    fprintf(logfile, "%0.0f low expression values in data.\n", sum);

  // print data
  if(VERBOSE) {
    std::cout << "\nData:\n";
    for (int i = 0; i < numGenes; i++) {
      for (int j = 0; j < numInd; j++)
	std::cout << data[i][j] << " ";
      std::cout << std::endl;
    }
  }

  // compute average frequencies
  for (int i = 0; i < numGenes; i++)
    for (int j = 0; j < 2; j++)
      freq[i][j] /= (float)numIndNoMiss[i];

  // print frequencies
  if (VERBOSE) {
    std::cout << "\nFrequencies for high- and low-expressions:\n";
    for (int i = 0; i < numGenes; i++) {
      for (int j = 0; j < 2; j++)
	std::cout << freq[i][j] << " ";
      std::cout << std::endl;
    }
  }

  // compute frequency factors
  for (int i = 0; i < numGenes; i++)
    for (int j = 0; j < 2; j++)
      freq[i][j] = 1.0 - (freq[i][j] / FREQWT);
      
  fclose(logfile);
  
  // find edges and output to file
  long int numEdges = findEdges(data, freq, argv[2], numInd, numGenes, logfileName, thresh, id, numIndNoMiss); 
 
  if ((logfile = fopen(logfileName, "a")) == NULL)
    fatal("Log file could not be opened.\n");
     
  for (int i = 0; i < numGenes; i++)
	delete [] data[i];
  delete [] data;
  
  t.stop("\nTimer stopped.");
  std::cout << t << " seconds.\n" << std::endl;
  
  double compTime;
  compTime = t.timeVal();
  
  if (LOG_FILE)
    fprintf(logfile, "%f seconds.\n\n", compTime);

  //std::cout << numEdges << std::endl;

  fclose(logfile);

  return numEdges;
}



int compThresh(char *inputFile, int numInd, int numGenes, int numHeadCols, int numHeadRows, float percentHiLo, float *hiLo, char *logfileName) {
  char strng[STRNG_LENGTH]; // string to hold information temporarily
  long int numMissing = 0; // number of missing data values

  if (!QUIET) 
  std::cout << "\nFinding thresholds for labeling high and low expression for " << numGenes << " analytes for " << numInd << " individuals..." << std::endl;
 
  FILE *input;
  FILE *logfile;
 
  if ((input = fopen(inputFile, "r")) == NULL)
    fatal("Input file could not be opened.\n");
    
  if ((logfile = fopen(logfileName, "a")) == NULL)
    fatal("Log file could not be opened.\n");
    
  // allocate memory into an array for holding all expression values
  float *data;
  int size = numGenes*numInd;
  if((data = new float[size]) ==NULL)
    fatal("memory not allocated");

  // read in header information
  int numCols = numHeadCols + numInd; 
  for (int i = 0; i < numHeadRows; i++)
    for (int j = 0; j < numCols; j++) 
      fscanf(input, "%s", strng); // not using header info
  
  // read in and record data
  for (int i = 0; i < numGenes; i++) {
    for (int j = 0; j < numHeadCols; j++) {
      if (feof(input))
	fatal("Missing data in input file");
      fscanf(input, "%s", strng); // not using header info
    }
    
    for (int j = 0; j < numInd; j++) {
      if (feof(input))
	fatal("Missing data in input file"); 
      fscanf(input, "%s", strng);

      /*      
      // check to see if number is in scientific notation
      for (int k = 0; k < STRNG_LENGTH; k++)
	if ((strng[k] == 'E') || (strng[k] == 'e')) {
	  if(VERBOSE)
	    std::cout << strng << " needs to be converted to float." << std::endl;
	  convertSciNotation(strng);
	  break;
	} 
	*/

      // check that strng holds a number
      int ascii = (int)strng[0]; // ascii value of first character
      int missingFlag = 0; // flag for missing data

      if((ascii < 48) || (ascii > 57)) { // not a digit
	      if((ascii != 45) && (ascii != 46)) { // not a '-' or '.'
	  
	        if(ascii == 78) { // starts with 'N' for missing data
	          if (strncmp(strng, "N", 1) == 0) {
	            missingFlag = 1; // set missing flag
	        }
	        else {
	          std::cout << strng << std::endl;
	          fatal("Invalid expression value in input file");
	        }
	      }
	
	      else {
	        std::cout << strng << std::endl;
	        fatal("Invalid expression value in input file");
	      }
	    }
     }
 
      if (missingFlag)
        data[i* numInd + j] = MAX_EXP + 1; // set missing to more than max expression value
      else
        data[i* numInd + j] = atof(strng);
    }
  }

  if (VERBOSE) {
    std::cout << "Data read in:" << std::endl;
    for (int i = 0; i < numGenes; i++) {
      for (int j = 0; j < numInd; j++)
	std::cout << data[i*numInd + j] << " ";
      std::cout << std::endl;
    }
  }

  // check for end of file
  if(!feof(input)) {
	fscanf(input, "%s", strng);
	if (!feof(input))
	  fatal("Unread information in input file");
  }

  fclose(input);

  double avgdata = 0.0;
  double median;
 
  if (size < 2)
    fatal("Less than 2 values in input");
     
  std::sort(data, data + size); // sort data using quicksort

  int actualNum = 0; // actual number of values without including missing value flags
  
  for (int i = 0; i < size; i++)
    if (data[i] < MAX_EXP + 1.0 - TOL) // not missing data
      actualNum++;
      
  std::cout << "Detected " << size - actualNum << " missing values." << std::endl;
  
  if(LOG_FILE)
    fprintf(logfile, "Detected %d missing values.\n", size - actualNum);

  if ((actualNum % 2) == 0)  // an even number of data
      median = 0.5 * (data[actualNum/2] + data[actualNum/2 - 1]);
    
    else        // odd number of data
      median = data[actualNum/2];

    for (int i = 0; i < actualNum; i++)     // find mean of data
      avgdata += data[i];
    avgdata /= (double)actualNum;


  if (VERBOSE) {
    std::cout << "Sorted data:" << std::endl;
    for (int i = 0; i < size; i++)
      std::cout << data[i] << " ";
    std::cout << "\n" << std::endl;
  }

  if(!QUIET)
    std::cout << "Average value = " << avgdata << ", median = " << median << std::endl;

  //determine number of values above/below threshold
  float temp = (float)actualNum * percentHiLo;
  int num = (int)ceil(temp); // round up 

  if(!QUIET)
    std::cout << "At least " << num << " values above and below thresholds." << std::endl;

  if (num < 1)
    fatal("Must have at least one value above or below threshold");

  hiLo[0] = data[num-1]; // lower threshold
  hiLo[1] = data[actualNum-num];  // upper threshold

  if (VERBOSE) {
    std::cout << "Upper threshold = " << hiLo[1] << std::endl;
    std::cout << "Lower threshold = " << hiLo[0] << "\n" << std::endl;
  }
  
  if(!QUIET){
    // count number of ties
    int ties = 0; // number of ties
    
    for (int i = 0; i < actualNum; i++)
      if(data[i] >= hiLo[1] - TOL) // allow for round-off error
	      ties++;
    
    std::cout << ties - num << " values are added due to ties for upper threshold." << std::endl;
    
    ties = 0; // number of ties
    
    for (int i = 0; i < actualNum; i++)
      if(data[i] <= hiLo[0] + TOL) // allow for round-off error
	      ties++;
    
    std::cout << ties - num << " values are added due to ties for lower threshold.\n" << std::endl;
  }
  
  delete [] data;
  fclose(logfile);
  
  return 1;
}


long int findEdges(char **data, double **freq, char *outFile, int numInd, int numGenes, char *logfileName, float thresh, char **id, int *numIndNoMiss) {
  FILE *output;
  FILE *logfile;
  
  if ((output = fopen(outFile, "w")) == NULL)
      fatal("Output file could not be opened.\n");
      
  if ((logfile = fopen(logfileName, "a")) == NULL)
    fatal("Log file could not be opened.\n");

  char strng[STRNG_LENGTH];
  int numNodes = 2 * numGenes; // number of nodes in network

  float maxXcorr = -1.0; // initialize for finding maximum xcorr value
  float minXcorr = 2.0; // intialize for finding minimum of each maximum xcorr value

  long int bins[NUMBINS]; // bins to hold tally of max xcorr values in each range
  double binVals[NUMBINS]; // hold thresholds

  for (int i = 0; i < NUMBINS; i++) 
    bins[i] = 0; // initialize to zero

  // set thresholds for each bin
  double incr = 1.0 / (double)NUMBINS;
  binVals[0] = incr;
  for (int i = 1; i < NUMBINS; i++)
    binVals[i] = binVals[i-1] + incr;

  if (PRINT_BINS)
    std::cout << "Bins are being computed, which increases computation time.\nHighest bin value is " << binVals[NUMBINS-1] << ".\n" << std::endl;

  // print out nodes to output file
  if(PRINTGML) {
    if (TWONODE) {
      fprintf(output, "Graph with %d nodes. \ngraph\n[\n", numNodes);
      for (int j = 1; j <= numGenes; j++) {
        if (PRINT_ID)  
          fprintf(output, "\tnode \n\t[\n\tid %d \n\tlabel \"%s|LO\"", j, id[j-1]);
        else
          fprintf(output, "\tnode \n\t[\n\tid %d", j);
          
        if(PRINT_PERCENT_MISSING)
          fprintf(output, "\n\tpercentMiss %f", 1.0 - (float)numIndNoMiss[j-1] / (float)numInd);
          
        fprintf(output, "\n\t]\n");
      }
      for (int j = numGenes + 1; j <= numNodes; j++) {
        if (PRINT_ID)  
          fprintf(output, "\tnode \n\t[\n\tid %d\n\tlabel \"%s|HI\"", j, id[j-numGenes-1]);
        else
          fprintf(output, "\tnode \n\t[\n\tid %d", j);   
    
        if(PRINT_PERCENT_MISSING)
          fprintf(output, "\n\tpercentMiss %f", 1.0 - (float)numIndNoMiss[j-numGenes-1] / (float)numInd);      
          
        fprintf(output, "\n\t]\n");              
      }
    }
    
    else {
      fprintf(output, "Graph with %d nodes. \ngraph\n[\n", numGenes);
      for (int j = 1; j <= numGenes; j++)
        if (PRINT_ID)
	        fprintf(output, "\tnode \n\t[\n\tid %d \n\tlabel \"%s\"\n\t]\n", j, id[j-1]);
        else
          fprintf(output, "\tnode \n\t[\n\tid %d \n\t]\n", j);
    }
  }

  // append edge numbers to file for running multiple random trials

  FILE *appendEdge;
  if(APPENDEDGES) {
    if ((appendEdge = fopen("edgeList.txt", "r")) != NULL) {
      std::cout << "\nAppending edges to existing 'edgeList.txt' file.\n" << std::endl;
      fclose(appendEdge);
    }

    else 
      std::cout << "\nWriting out edges to new 'edgeList.txt' file.\n" << std::endl;

    if ((appendEdge = fopen("edgeList.txt", "a")) == NULL)
      fatal("edgeList.txt file could not be opened.\n");

    fprintf(appendEdge, "Source   Target   Weight\n");
  }

  srand(time(NULL)); // set random seed

  float duo[5]; // hold 4 different relationships + percent of individuals with no missing dataf for the two analytes
  float tempDuo[5]; // hold temporary values for randomized validation trials
  long int numEdges = 0; // tally number of edges printed out
  long int numNotValid = 0; // tally number of edges that don't pass validation

  // tally pairwise regulations
  for (int i = 0; i < numGenes-1; i++) 
    for (int j = i+1; j < numGenes; j++) {

      // compute Duo
      compDuo(duo, data[i], data[j], freq[i], freq[j], numInd);

      if (VERBOSE) 
	std::cout << i+1 << ", " << j+1 << ": " << "UU = " << duo[0] << ", UD = " << duo[1] << ", DU = " << duo[2] << ", DD = " << duo[3] << ", percentNoMiss " << duo[4] << std::endl;

      float max = duo[0]; // find maximum value
      if (duo[1] > max)
	max = duo[1];
      if (duo[2] > max)
	max = duo[2];
      if (duo[3] > max)
	max = duo[3];

      if(VERBOSE)
	std::cout << "Max = " << max << std::endl;

      // check that values are valid
      if((duo[0] > 1.5 + TOL) || (duo[0] < 0.0 - TOL))
	fatal("Invalid value computed for UU relationship.");

      if((duo[1] > 1.5 + TOL) || (duo[1] < 0.0 - TOL))
	fatal("Invalid value computed for UD relationship.");

      if((duo[2] > 1.5 + TOL) || (duo[2] < 0.0 - TOL))
	fatal("Invalid value computed for DU relationship.");

      if((duo[3] > 1.5 + TOL) || (duo[3] < 0.0 - TOL))
	fatal("Invalid value computed for DD relationship.");
      
      // validate correlation by running permutation trials
      int isValid = 1; // set to 0 if not a valid edge

      if (max > thresh - TOL) {
	if (VALIDATE && VERBOSE)
	  std::cout << "Validating correlation between " << i+1 << " and " << j+1 << "..." << std::endl; 

	if(VALIDATE)
	  isValid = validate(tempDuo, data[i], data[j], freq[i], freq[j], numInd, max);

	if(!isValid)
	  numNotValid++;

	if(isValid) { // have a valid edge to record and print
	  	  
    // update maximum and minimum values found for data set
    if (max > maxXcorr)
	    maxXcorr = max;
      
    if (max < minXcorr)
	    minXcorr = max;

	  if(PRINT_BINS) { // tally values
	    for (int ptr = 0; ptr < NUMBINS; ptr++)
	      if (max <= binVals[ptr]) {
		bins[ptr]++;
		break;
	      }
	  }
	
	// print out significant edges
	  if (!TWONODE) // just one possible edge to print out
	    if (max > thresh - TOL) {
	      fprintf(output, "\tedge\n\t[\n\tsource %d\n\ttarget %d\n\tweight %f", i+1, j+1, max);
        
        if(PRINT_PERCENT_MISSING)
          fprintf(output, "\n\tpercentMiss %f\n\t]\n", 1.0 - duo[4]);
        else
          fprintf(output, "\n\t]\n");
          
	      numEdges++;
	    }
	  
	  if (TWONODE) { // four different possible edges to print out
     
	    if(duo[0] > thresh - TOL) { 
	      fprintf(output, "\tedge\n\t[\n\tsource %d\n\ttarget %d\n\tweight %f", i+numGenes+1, j+numGenes+1, duo[0]);
        
        if(PRINT_PERCENT_MISSING)
          fprintf(output, "\n\tpercentMiss %f\n\t]\n", 1.0 - duo[4]);
        else
          fprintf(output, "\n\t]\n");
	    
	      if(APPENDEDGES)
		fprintf(appendEdge, "%d %d %f %f\n", i+numGenes+1, j+numGenes+1, duo[0], duo[4]); 
	      
	      numEdges++;	
	    }
	    
	    if(duo[1] > thresh - TOL) { 
	      fprintf(output, "\tedge\n\t[\n\tsource %d\n\ttarget %d\n\tweight %f", i+numGenes+1, j+1, duo[1]);
             
        if(PRINT_PERCENT_MISSING)
          fprintf(output, "\n\tpercentMiss %f\n\t]\n", 1.0 - duo[4]);
        else
          fprintf(output, "\n\t]\n");
	      
	      if(APPENDEDGES)
		fprintf(appendEdge, "%d %d %f %f\n", i+numGenes+1, j+1, duo[1], duo[4]); 
	      
	      numEdges++;
	    }
	    
	    if(duo[2] > thresh - TOL) { 
	      fprintf(output, "\tedge\n\t[\n\tsource %d\n\ttarget %d\n\tweight %f", i+1, j+numGenes+1, duo[2]);
             
        if(PRINT_PERCENT_MISSING)
          fprintf(output, "\n\tpercentMiss %f\n\t]\n", 1.0 - duo[4]);
        else
          fprintf(output, "\n\t]\n");
	      
	      if(APPENDEDGES)
		fprintf(appendEdge, "%d %d %f %f\n", i+1, j+numGenes+1, duo[2], duo[4]); 
	      
	      numEdges++;
	    }
	    
	    if(duo[3] > thresh - TOL) { 
	      fprintf(output, "\tedge\n\t[\n\tsource %d\n\ttarget %d\n\tweight %f", i+1, j+1, duo[3]);
             
        if(PRINT_PERCENT_MISSING)
          fprintf(output, "\n\tpercentMiss %f\n\t]\n", 1.0 - duo[4]);
        else
          fprintf(output, "\n\t]\n");
	      
	      if(APPENDEDGES)
		fprintf(appendEdge, "%d %d %f %f\n", i+1, j+1, duo[3], duo[4]); 
	      
	      numEdges++;
	    }
	  }

	  if(numEdges > MAXNUMEDGES)
	    fatal("Too many edges output.  Check MAXNUMEDGES in header file.");
	}
      }
    } // end of for (int j = i+1) loop

  fprintf(output, "]\n"); // print closing bracket

  fclose(output);

  if(APPENDEDGES) {
    fclose(appendEdge);
  }

  if(VALIDATE)
    std::cout << "\n" << numNotValid << " edges did not pass the validation test." << std::endl;

  std::cout << "\nPrinted " << numEdges << " edges, which are significant (p-val = " << MAXPERCENT << ") following " << NUMRANDTRIALS << " permutation trials." << std::endl;

  std::cout << "Duo values range from " << minXcorr << " to " << maxXcorr << "." << std::endl;
  
  if(LOG_FILE) {
    if(VALIDATE)
      fprintf(logfile, "\n%d edges did not pass the validation test.\n", numNotValid); 

    fprintf(logfile, "\nPrinted %d edges, which are significant (p-val = %0.3f) following %d permutation trials.\nDuo values range from %f to %f.\n", numEdges, MAXPERCENT, NUMRANDTRIALS, minXcorr, maxXcorr);
  }

  if (PRINTNUMEDGESINFO) { // print number of edges to "numEdgesInfo.txt"
    FILE *edgeFile;

    // check if new file, if so print out header
    if ((edgeFile = fopen("numEdgesInfo.txt", "r")) == NULL) { 
      if ((edgeFile = fopen("numEdgesInfo.txt", "w")) == NULL)
	fatal("'numEdgesInfo.txt' file could not be opened.\n");

      fprintf(edgeFile,"NumIndiv Thresh NumEdges MaxDuo\n"); 
      fclose(edgeFile);
    }

  if ((edgeFile = fopen("numEdgesInfo.txt", "a")) == NULL)
    fatal("'numEdgesInfo.txt' file could not be opened.\n");

  fprintf(edgeFile,"%d %.5f %d %.5f\n", numInd, thresh, numEdges, maxXcorr);
  fclose(edgeFile);
  }

  if (PRINTNUMEDGES) { // print number of edges to overwrite "numEdges.txt"
    FILE *edgeFile;

  if ((edgeFile = fopen("numEdges.txt", "w")) == NULL)
    fatal("'numEdges.txt' file could not be opened.\n");

  fprintf(edgeFile,"%d\n", numEdges);
  fclose(edgeFile);
  }

  fclose(logfile);
  
  return numEdges;
}



int compDuo(float *duo, char *data1, char *data2, double *freq1, double *freq2, int numInd) {
      // initialize values
      duo[0] = 0.0;  // both up-regulated
      duo[1] = 0.0; // first up- and second down-regulated
      duo[2] = 0.0; // first down- and second up-regulated
      duo[3] = 0.0; // both down-regulated

      int numIndNoMiss = numInd; // initialize to all, subtract when missing values

      for (int k = 0; k < numInd; k++) {
	if (data1[k] == '2') { // first one is up-regulated
	  if (data2[k] == '2') // second one is up-regulated
	    duo[0]++; 

	  if (data2[k] == '0') // second one is down-regulated
	    duo[1]++;
	}

	if (data1[k] == '0') { // first one is down-regulated
	  if (data2[k] == '2') // second one is up-regulated
	    duo[2]++;

	  if (data2[k] == '0') // second one is down-regulated
	    duo[3]++;
	}

	if ((data1[k] == '3') || (data2[k] == '3')) // one or other is missing data
	  numIndNoMiss--; // one less without missing data
 }

  if (0)
	  std::cout << numIndNoMiss << " individuals without missing data for both analytes." << std::endl;  
     
  duo[4] = (float)numIndNoMiss / (float)numInd; // track percent of individuals without missing data

      // divide each by number of individuals to get average
      duo[0] /= (float)numIndNoMiss; 
      duo[1] /= (float)numIndNoMiss;
      duo[2] /= (float)numIndNoMiss;
      duo[3] /= (float)numIndNoMiss;

      // multiply by frequency factors
      if (FREQ) {
	duo[0] *= freq1[0] * freq2[0]; // multiply by both up-reg frequency factors
	duo[1] *= freq1[0] * freq2[1]; // multiply by up-reg for i and down-reg for j
	duo[2] *= freq1[1] * freq2[0]; // multiply by down-reg for i and up-reg for j
	duo[3] *= freq1[1] * freq2[1]; // multiply by both down-reg factors
      }

      // multiply by scaling factor
      duo[0] *= SCALEFACTOR; 
      duo[1] *= SCALEFACTOR; 
      duo[2] *= SCALEFACTOR; 
      duo[3] *= SCALEFACTOR; 


  return 1;
}


int validate(float *tempDuo, char *data1, char *data2, double *freq1, double *freq2, int numInd, float duoVal) {

  int numEdges = 0; // count total number of edges for trials
  int isValid = 0; // set to one if valid
  int randomVal; // hold random integer

  char *randData; // hold randomized values
  if ((randData = new char[numInd]) == NULL)
    fatal("memory not allocated");

  // run randomized trials
  for (int trial = 0; trial < NUMRANDTRIALS; trial++) {
    // initialize values
    for (int i = 0; i < numInd; i++)
      randData[i] = '\0'; // initialize to null
    
    // randomize data1 (no need to randomize data2 also)
    for (int i = 0; i < numInd; i++) {
      // assign random value between 0 and numInd-1
      randomVal = rand() % numInd;
      
      while(randData[randomVal] != '\0') // check for data already taken
	randomVal = rand() % numInd;
      
      randData[randomVal] = data1[i]; // assign data1 value to new individual
    }
    
    if (0) {
      for (int i = 0; i < numInd; i++)
	std::cout << randData[i] << " ";
      std::cout << std::endl;
    }

    // compute Duo
    compDuo(tempDuo, randData, data2, freq1, freq2, numInd);

    for (int i = 0; i < 4; i++)
      if(tempDuo[i] > duoVal - TOL) {
	numEdges++;
	break; // count only one for each trial (use % of trials)
      }
  }

  if (VERBOSE)
    std::cout << numEdges << " edges found in randomized trials." << std::endl;

  float percent = (float)numEdges / (float)NUMRANDTRIALS;

  if (percent < MAXPERCENT+TOL)
    isValid = 1; // within the tolerance allowed

  if (VERBOSE)
    std::cout << percent * 100.0 << "% of the trials produced at least one edge." << std::endl;
  
  delete [] randData;

  return isValid;
}


void checkConstants()   // check duo.h for expected values
{
  if(FREQ != true)
    fatal("FREQ value in duo.h should be 'true'.");
     
  if ((FREQWT > 1.5 + TOL) || (FREQWT < 1.5 - TOL))
    warning("Default frequency weight is 1.5.  Check FREQWT in duo.h");
 
  if((SCALEFACTOR > 4.0 + TOL) || (SCALEFACTOR < 4.0 - TOL))
    warning("Invalid value for NOMISS in bloc.h.");
 
  if((TOL > 0.0001) || (TOL < -0.0001))
    warning("Check value for TOL in duo.h.");
    
  if(PRINTGML != true)
    warning("PRINTGML value in duo.h should be true for network to be recorded.");

  if(TWONODE != true)
    fatal("TWONODE value in duo.h should be true.");
}