// -------------------------------------------------------------------------
// d2d.h -   Header file for Difference in 2-cluster Distances (d2d)
//
// Sharlee Climer
//
// ------------------------------------------------------------------------

#ifndef _D2D_H
#define _D2D_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string.h>
#include <algorithm>

#include "timer.h"

// the following can be adjusted as needed:
const int QUIET = 0;  // set to one to reduce output to screen
const int VERBOSE = 0;  // set to one to display maximum output to screen

const int NORMALIZE = 0; // set to 1 if data wasn't previously normalized
const float MINSUBSETPERCENT = 0.05; // minimum percentage of individuals in a subtype
const int IND_ID_ROW = 1; // row that holds individuals' IDs (default = 1)
const int ANALYTE_LABEL = 1; // column containing analyte label in expression file
const int MAX_SIZE = 1000; // maximum size of pattern to be tested

const int NUMPERMUTATIONS = 10000; // number of permutations used to compute p-value
const float PVAL_THRESH = 0.05; // p-value threshold
const int USE_YOUJ_SIG = 1; // set to 1 if use Youden's J for significance rather than d2d values

const bool LOG_FILE = true; // set to true to print out log file
const bool SIG_FILE = true; // set to true to print significant analytes to a separate file

const int MAX_NUM_INDIVIDUALS = 100000; // maximum number of individuals (can be adjusted)
const int MAX_NUM_ANALYTES = 10000000; // maximum number of analytes (can be adjusted)
const int MAX_STRING_LENGTH = 100; // general limit on string length (can be adjusted)
const int MAX_LABEL_LENGTH = 1000; // string length for analyte labels (can be adjusted)
const int FILENAMELENGTH = 500; // maximum filename length (can be adjusted)
const float MAX_EXP = 500000.0; // maximum expression level allowed in input (can be adjusted)
const float MIN_EXP = -500000.0; // minimum expression level allowed in input (can be adjusted)
const float NOTALLOWEDVALUE = MIN_EXP - 1.0; // extreme value to flag missing or unused data
const double TOL = 0.000001; // tolerance (can be adjusted)

// the following should not be changed without good reason:
const int NUM_STRINGS_INFO_SIG_FILE = 4; // number of strings at the beginning of the .sig file
const int NUM_STATS_SIG_FILE = 7; // number of statistics columns in the .sig file that is output
const int NUM_STRNGS_HEAD_BFS = 6; // number of strings at the beginning of the .bfs file
const float MINVAL = 0; // minimum value for normalized data
const float MAXVAL = 1; // maximum value for normalized data


inline void warning(const char* p) { fprintf(stderr,"Warning: %s \n",p); }
inline void fatal(const char* string) {fprintf(stderr,"\nFatal: %s\n\n",string); exit(1); }


#endif
