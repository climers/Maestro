// -------------------------------------------------------------------------
// normalize.h
//
// written by Sharlee Climer, August 2024
//
// ------------------------------------------------------------------------

#ifndef _NORMALIZE_H
#define _NORMALIZE_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>

void normalize(float *data, int numRows, float minVal, float maxVal, float missingValFlag);

#endif
