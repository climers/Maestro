/*   
 *
 *   normalize.cpp 
 *
 *   Program to normalize a list of values while retaining their IDs and input order
 *   Uses IQR and IQR_FACTOR (defined in normalize.h) to Winsorize outliers
 *   Values are scaled and shifted to desired range
 *
 *   Written by Sharlee Climer
 *   August 2024
 *
 * 
 *
*/

#include "normalize.h"

const float IQR_FACTOR = 1.0; // multiply the IQR times this value and use to to subtract/add to Q1/Q3 for winsorizing outliers
const int MAXSTRNGLENGTH = 200; // number of chars in maximum string length
const int QUIET = 1;  // set to one to eliminate output to screen
const int VERBOSE = 0;  // set to one to display maximum output to screen
const float TOL = 0.00001; // tolerance
inline void warning(const char* p) { fprintf(stderr,"Warning: %s \n",p); }
inline void fatal(const char* string) {fprintf(stderr,"\nFatal: %s\n\n",string); exit(1); }

void checkValidInt(char *strng, float missingValFlag);
void checkValidFloat(char *strng, float missingValFlag);
void mergeSort(float *data, int *order, int left, int right, float missingValFlag);
void merge(float *data, int *order, int left, int mid, int right, float missingValFlag);
void printFloatArray(float *data, int size);
void printStringArray(char **data, int size);
void printIntArray(int *data, int size);
int clipOutliers(float *data, int size, float missingValFlag);
void scaleShift(float *data, int size, float minVal, float maxVal);

void normalize(float *data, int numRows, float minVal, float maxVal, float missingValFlag)
{
  if (!QUIET) 
    std::cout << "Normalizing " << numRows << " data values.\nOutliers will be winsorized using interquartile range and IQR_FACTOR of " << IQR_FACTOR << " (as specified in 'normalize.cpp').\nValues will then be scaled and shifted to range from " << minVal << " to " << maxVal << ".***Assuming that values of " << missingValFlag << " represent missing data.***\n\n";

  // allocate memory for array to hold copy of data values
  int numNoMissing; // will hold number of data values that don't represent missing data
  float *copy;
  if((copy = new float[numRows]) == NULL)
    fatal("memory not allocated");  
    
  // copy data values
  for (int i = 0; i < numRows; i++)
    copy[i] = data[i];       
       
  // allocate memory for array to hold ordering of the values
  int *order;
  if((order = new int[numRows]) == NULL)
    fatal("memory not allocated");   
    
  // allocate memory for array to hold index of ordering
  int *indexOrder;
  if((indexOrder = new int[numRows]) == NULL)
    fatal("memory not allocated");   
    
  // initialize order array (numbers will be sorted along with corresponding values)
  for (int i = 0; i < numRows; i++)
    order[i] = i;
    
  //sort data values while preserving original order with mapping in order array
  mergeSort(copy, order, 0, numRows-1, missingValFlag); 

  // translate ordering to direct indices 
  for (int i = 0; i < numRows; i++)
    indexOrder[order[i]] = i; 

    if (VERBOSE) {
    std::cout << "\nSorted values:\n";
    printFloatArray(copy, numRows);
  }
  
  if (0) {
    std::cout << "\nOrdering of values:\n";
    printIntArray(order, numRows);
    std::cout << "\nIndexOrdering:\n";
    printIntArray(indexOrder, numRows);
  }
  
  numNoMissing = clipOutliers(copy, numRows, missingValFlag); // winsorize outliers using IQR and IQR_FACTOR

  scaleShift(copy, numNoMissing, minVal, maxVal); // scale and shift values to specified range
  
  if (VERBOSE) {
    std::cout << "Normalized values:\n";
    printFloatArray(copy, numRows);
  }
  
  // overwrite data array with original ordering 
  for (int i = 0; i < numRows; i++) 
    data[i] = copy[indexOrder[i]];

  if (VERBOSE) {
    std::cout << "Normalized values in their original ordering:\n";
    printFloatArray(data, numRows);
  }

  delete [] copy;
  delete [] order;
  delete [] indexOrder;
}



void checkValidInt(char *strng, float missingValFlag) {  // checks string to see if it starts with a valid character for a float
    int ascii;
    int digit = 0;

    while (strng[digit] != '\0') { // check each digit
        ascii = (int) strng[digit]; // ascii value of next character
        if ((ascii < 48) || (ascii > 57)) { // not a digit
            if ((digit != 0) && (ascii == 45)) { // not a '-' at the beginning     
                std::cout << strng << std::endl;
                fatal("Invalid input value. Expected an integer.");
            }
        }
        digit++;
    }
    
    int temp = atoi(strng);
    if (temp > missingValFlag-1)
        fatal("Input value exceeds maximum allowed (change value in header file).");
}


void checkValidFloat(char *strng, float missingValFlag) {  // checks string to see if it starts with a valid character for a float
    int ascii;
    int digit = 0;

    while (strng[digit] != '\0') { // check each digit
        ascii = (int) strng[digit]; // ascii value of next character
        if ((ascii < 48) || (ascii > 57)) { // not a digit
          if (ascii != 46) { // not a '.' (multiple decimal points could get by this check)
            if ((ascii == 45) && (digit != 0)) { // not a '-' at the beginning
                std::cout << strng << std::endl;
                fatal("Invalid data value in input file");
            }
          }
        }
        digit++;
    }
    
    float temp = atof(strng);
    if (temp > missingValFlag-1)
        fatal("Input value exceeds maximum allowed (change value in header file).");
}


void mergeSort(float *data, int *order, int left, int right, float missingValFlag) { // use mergesort to sort values (preserve original mapping in order array)
    if (left < right) { // left and right are the indices of the subportion of the array 
        int mid = (left + right) / 2;
        mergeSort(data, order, left, mid, missingValFlag); // recursively split left side
        mergeSort(data, order, mid+1, right, missingValFlag); // recursively split right side
        
        merge(data, order, left, mid, right, missingValFlag); // merge sorted arrays together
    }
}



void merge(float *data, int *order, int left, int mid, int right, float missingValFlag) {
    int i, j, k; // loop counters, then index pointers
    int n1 = mid - left + 1; // size of left subarray
    int n2 = right - mid; // size of right subarray
    
    float *leftArray, *rightArray; // create subarrays
    if(((leftArray = new float[n1+2]) == NULL) || ((rightArray = new float[n2+2]) == NULL))
        fatal("memory not allocated");   
        
    int *leftOrder, *rightOrder; // create subarrays for copying order values
    if(((leftOrder = new int[n1+2]) == NULL) || ((rightOrder = new int[n2+2]) == NULL))
        fatal("memory not allocated");   
    
    // copy data to temp arrays    
    for (i = 1; i <= n1; i++) {
        leftArray[i] = data[left + i - 1];   
        leftOrder[i] = order[left + i - 1];
    }
        
    for (j = 1; j <= n2; j++) {
        rightArray[j] = data[mid + j];
        rightOrder[j] = order[mid + j];
    }
            
    leftArray[n1 + 1] = rightArray[n2+1] = missingValFlag + 10.0; // set to infinity 
        
    // merge the temp arrays and overwrite the original array
    i = 1; // initialization of subarray pointers
    j = 1; 
    
    for (int k = left; k <= right; k++) {
        if (leftArray[i] <= rightArray[j]) {
            data[k] = leftArray[i];
            order[k] = leftOrder[i];
            i++;
        }
        else {
            data[k] = rightArray[j];
            order[k] = rightOrder[j];
            j++;
        }
    }

    delete [] leftArray;
    delete [] rightArray;
}



void printFloatArray(float *data, int size) {  // print array of floats
    for (int i = 0; i < size; i++)
        std::cout << "\t" << data[i] << "\n";
    std::cout << "\n";
}

void printStringArray(char **data, int size) {  // print array of strings
    for (int i = 0; i < size; i++)
        std::cout << "\t" << data[i] << "\n";
    std::cout << "\n";
}

void printIntArray(int *data, int size) {  // print array of ints
    for (int i = 0; i < size; i++)
        std::cout << "\t" << data[i] << "\n";
    std::cout << "\n";
}

// assuming missing data values are equal to missingValFlag, and that this value is greater than any other data value 
int clipOutliers(float *data, int size, float missingValFlag) { // wonsorize outliers using IQR and IQR_FACTOR ***assumed data is pre-sorted in ascending order***    
    int numNoMissing; // number of values in the array that don't represent missing data
    float median; // median (Q2)
    int halfSize; // floor of half the size of the array
    float q1, q3; // lower (Q1) and upper (Q3) quartile values 
    int halfLeft; // floor of halfway point in left half of array
    int halfRight; // floor of halfway point in right half of array
    float iqr; // interquartile range (IQR)
    float lowestVal, highestVal; // lowest and highest values after winsorizing outliers
    int ptr; // pointer for traversing array
    
    // account for missing values
    numNoMissing = size; // initialize to all of the data
    ptr = size - 1; // point to highest value in array
    while(data[ptr] >= missingValFlag - TOL) {
        numNoMissing--; // decrement for each missing value
        ptr--;
    }
        
    //std::cout << "\n\n\tmissingValFlag = " << missingValFlag << ", size = " << size << ", numNoMissing = " << numNoMissing << "\n\n";
    
    // determine median
    halfSize = numNoMissing/2; // halfway point in data or value just below half if even number of values
    if (numNoMissing % 2 == 0) // even number of data points
        median = (data[halfSize - 1] + data[halfSize]) / 2.0; // take average of the two flanking values
    else // odd number of data points
        median = data[halfSize];    
    
    // determine lower (Q1) quartile value
    halfLeft = halfSize/2; // halfway point in left half of data or value just below half if even number of values
    if (halfSize % 2 == 0) // even number of data points
        q1 = (data[halfLeft - 1] + data[halfLeft]) / 2.0; // take average of the two flanking values
    else // odd number of data points
        q1 = data[halfLeft]; 

    // determine upper (Q3) quartile value
    halfRight = (size - halfSize) / 2; // halfway point in left half of data or value just below half if even number of values
    if ((numNoMissing - halfSize) % 2 == 0) // even number of data points
        q3 = (data[halfSize + halfRight - 1] + data[halfSize + halfRight]) / 2.0; // take average of the two flanking values
    else // odd number of data points
        q3 = data[halfSize + halfRight]; 
        
    // determine interquartile range (IQR)
    iqr = q3 - q1;
        
    // find lowest and highest allowed values
    lowestVal = q1 - (iqr * IQR_FACTOR); 
    highestVal = q3 + (iqr * IQR_FACTOR); 
    
    if (!QUIET)
        std::cout << "Winsorizing outliers: \n\tValues less than Q1 - (IQR * " << IQR_FACTOR << ") = " << lowestVal << " will be replaced by that minimum value \n\tValues greater than Q3 + (IQR * " << IQR_FACTOR << ") = " << highestVal << " will be replaced by that maximum value\n\n";

    if (0) 
      std::cout << "Median = " << median << ", Q1 = " << q1 << ", Q3 = " << q3 << ", IQR = " << iqr << ", lowest allowed value = " << lowestVal << ", highest allowed = " << highestVal << ".\n\n";
    
    // winsorize outliers
    ptr = 0;
    while (data[ptr] < lowestVal) 
        data[ptr++] = lowestVal;
        
    ptr = numNoMissing - 1;
    while (data[ptr] > highestVal) 
        data[ptr--] = highestVal;
    
    if (0) {
        std::cout << "Sorted and winsorized array:\n";
        printFloatArray(data, size); 
    }
    
    return numNoMissing;
}


void scaleShift(float *data, int size, float minVal, float maxVal) { // scale and shift values to specified range. Assumed data is sorted.
    float oldMin = data[0]; // minimum value in data array
    float oldMax = data[size-1]; // maximum value in data array
    
    //std::cout << "\nNumber of values = " << size << ", old min = " << oldMin << ", old max = " << oldMax << ".\n\n";
    
    for (int i = 0; i < size; i++) 
        data[i] = ((data[i] - oldMin) * (maxVal - minVal) / (oldMax - oldMin)) + minVal;
    }








































