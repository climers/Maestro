/*   
 *
 *   d2d.cpp 
 *
 *   Program to identify signficant associations using Difference in 2-cluster Distances (d2d)
 *
 *   Sharlee Climer
 *   June 2023
 *
 *   Extended to test analyte patterns. Additional input file with patterns shown by cluster numbers. 
 *   Outliers are trimmed, then values are normalized to 0 to 1. Analytes with low valued associations are inverted.
 *   Average value for the analytes and inverted analytes are used for the individual's measurement for d2d calculations.
 *   Sharlee Climer, August 2024.
 *
 *   v1.2: fixed minor bug (removed chance for erroneous tie in mergesort). Sharlee Climer, September 2024.
 *
 *   v2.0: Revised code to require command line specification of the numbers of header rows and header columns. Also made 
 *   normalization optional using NORMALIZE parameter, which is defined in d2d.h.
 *   Sharlee Climer, November 2026
 *
*/

#include "d2d.h"
#include "normalize.h"

void readHeaderRows(FILE *fileptr, int numInd, char ***headerRows, int numheadrows, int numheadcols);
int readDataRow(FILE *fileptr, int numInd, float *data, char ***headerCols, int currentGene, int numheadcols);
float comp2median(float *data, int minNumSubset, int numInd, int numMissing, float *boundaries);
float comp_odds_ratio(float *caseData, float *ctrlData, int nCase, int nCtrl, int numMissingCase, int numMissingCtrl, float *boundaries, float *oddsratio, int *tallies, float *youJ);
float comp_pval(float *caseData, float *ctrlData, int minNumSubsetCase, int minNumSubsetCtrl, int nCase, int nCtrl, int numMissingCase, int numMissingCtrl, float diffCaseCtrl, float thresh, int moreOrLess, float youJ, float *pvalYouJ);
bool is_significant(float pval, float *oddsratio, float pvalYouJ); 
void printIndfile(FILE *cases, FILE *ctrls, FILE *sigfile, FILE *indFile, int nCase, int nCtrl, int numGenes, int numheadrows, int numheadcols);
void checkValid(char *strng); 
void testIndAnalytes(int numGenes, FILE *ctrls, FILE *cases, int nCtrl, int nCase, char ***geneHeaderCols, int minNumSubsetCase, int minNumSubsetCtrl, FILE *sigfile, FILE *output, char *sigFileName, int numheadrows, int numheadcols); 
void testAllPatterns(int numGenes, FILE *ctrls, FILE *cases, FILE *patterns, int nCtrl, int nCase, char ***geneHeaderCols, int minNumSubsetCase, int minNumSubsetCtrl, FILE *sigfile, FILE *output, FILE *logfile, int numheadcols);
int readData(float **data, char ***labels, int numGenes, int nCase, int nCtrl, FILE *ctrls, FILE *cases, int numheadcols);
void comp_d2d(float **data, char ***labels, int numGenes, int nCase, int nCtrl, int numClusters, int **clusts, int *clustSize, char ***geneHeaderCols, int minNumSubsetCase, int minNumSubsetCtrl, FILE *sigfile,FILE *logfile, FILE *output, int numheadcols);


int main(int argc, char **argv) {
    if ((argc != 9) && (argc != 10)) 
        fatal("Usage:\n  d2d cases_expr.txt controls_exp.txt numCases numControls numAnalytes numHeaderRows numHeaderCols outputFile [patternFile.bfs]\n\n");

    timer t;

    t.start("Timer started");

    FILE *cases; // contains Cases genotypes
    FILE *ctrls; // contains Controls genotypes
    FILE *output; // will hold statistics for all analytes
    FILE *logfile; // copy screen output and hold all p-values
    FILE *sigfile; // will hold significant analytes' statistics
    FILE *inputPatterns; // point to pattern file if patterns are tested
    
    // check to be sure all files are available
    if (((cases = fopen(argv[1], "r")) == NULL) || ((ctrls = fopen(argv[2], "r")) == NULL))
        fatal("Input file could not be opened.\n");    
    
    int nCase = atoi(argv[3]);  // number of Cases individuals
    int nCtrl = atoi(argv[4]); // number of Controls
    int numGenes = atoi(argv[5]);  // number of analytes
    int numheadrows = atoi(argv[6]); // number of header rows
    int numheadcols = atoi(argv[7]); // number of header columns

    int numStates = 2 * numGenes; // number of analyte states (have up or down regulation)
    int numInd = nCase + nCtrl; // total number of individuals
    
    char strng[MAX_LABEL_LENGTH*MAX_LABEL_LENGTH]; // temporary string 
    int testPatterns = 0; // will change to 1 if patterns tested instead of individual analytes
    char logfileName[FILENAMELENGTH+4]; // hold name of logfile
    char sigFileName[FILENAMELENGTH+4]; // hold name of file for significant analytes data
    char base[FILENAMELENGTH]; // base for supplemental file names
    const char logSuffix[] = ".log"; // suffix for logfile name
    const char sigSuffix[] = ".sig"; // suffix for significant filename

    if (!QUIET) {
        std::cout << "Command line arguments: \n\t";
        for (int i = 0; i < argc; i++)
            std::cout << argv[i] << " ";
        std::cout << "\n" << std::endl;
    }

    if (argc == 10) {
      testPatterns = 1; // test patterns instead of individual analytes      
      std::cout << "\nPatterns defined in '" << argv[9] << "' will be tested.\n\n";
      if ((inputPatterns = fopen(argv[9], "r")) == NULL)
          fatal("Patterns file could not be opened.\n");
    }
    
    if ((output = fopen(argv[8], "w")) == NULL)
        fatal("Output file could not be opened.\n");
        
    // determine name for supplementary files
    for (int i = 0; i < 400; i++) {
        base[i] = argv[8][i]; // copy output file name
        if (base[i] == '\0') {
            if (i < 2)
                fatal("Expected output file name to have at least two characters");

            base[i] = '\0'; // set end of string
            break;
        }
    }

    sprintf(logfileName, "%s%s", base, logSuffix); // string together file name for logfile name
    sprintf(sigFileName, "%s%s", base, sigSuffix); // string together file name for significant file name

    if (LOG_FILE && !QUIET)
        std::cout << "Summary output will be recorded in '" << logfileName << "'.\n" << std::endl;
        
    if (SIG_FILE && !QUIET)
        std::cout << "Significant analytes will be recorded in '" << sigFileName << "'.\n" << std::endl;      

    if ((logfile = fopen(logfileName, "w")) == NULL)
        fatal("Log file could not be opened.\n");
        
    if ((sigfile = fopen(sigFileName, "w")) == NULL)
        fatal("File for significant analytes could not be opened.\n");        
        
    if (LOG_FILE) {
        fprintf(logfile, "\nCommand line arguments: \n\t");
        for (int i = 0; i < argc; i++)
            fprintf(logfile, "%s ", argv[i]);
        fprintf(logfile, "\n\n");
    }
    
    // print headers for output files  
    if(!testPatterns) 
        fprintf(output, "RowNum\t"); 

        
    if(SIG_FILE) {
        if(!testPatterns) 
            fprintf(sigfile, "RowNum\t"); 
        if(testPatterns)
            fprintf(sigfile, "Pattern\t");    
 
    }
    
    for (int i = 0; i < numheadcols; i++) { 
        fscanf(cases, "%s", strng);
        int k = 0; // walk through string to see if termination symbol exists
        while(k < MAX_LABEL_LENGTH) {
           if (strng[k] == '\0')
              break; 
           k++;
       }               
       if (k == MAX_LABEL_LENGTH - 1)
           fatal("Header label exceeds MAX_LABEL_LENGTH, revise header file\n");  
       if(!testPatterns)
           fprintf(output, "%s\t", strng);   
       if (SIG_FILE && !testPatterns)
           fprintf(sigfile, "%s\t", strng);   
    }
    
    if(!testPatterns)
        fprintf(output, "pval\tthresh\tnCases(%%)\tnCtrls(%%)\tOR(95%%CI)\tYoudenJ\tYoudenJ_pval\n");    
        
    if(SIG_FILE && !testPatterns)
       fprintf(sigfile, "pval\trelation\tthresh\tnCases(%%)\tnCtrls(%%)\tOR(95%%CI)\tYoudenJ\tYoudenJ_pval\n");
    if(SIG_FILE && testPatterns) {
       if(USE_YOUJ_SIG)
           fprintf(sigfile, "nAnalytes\tthresh\tnCases(%%)\tnCtrls(%%)\tOR(95%%CI)\tYoudenJ\tYoudenJ_pval\n");
       else
           fprintf(sigfile, "nAnalytes\tpval\tthresh\tnCases(%%)\tnCtrls(%%)\tOR(95%%CI)\tYoudenJ\tYoudenJ_pval\n");
    }
    rewind(cases); 

    if (!QUIET) {
        std::cout << "Checking for associations for diseased cases in '";
        std::cout << argv[1] << "' when compared to normal controls in '" << argv[2] << "'.\n";
    }

    if (LOG_FILE) {
        fprintf(logfile, "Checking for associations for diseased cases in '%s' when compared to normal controls in '%s'.\n", argv[1], argv[2]);
        
        if (testPatterns)
          fprintf(logfile, "Patterns given in '%s' will be tested for associations.\n", argv[9]);
    }

    if (!QUIET) {
        std::cout << nCase << " Cases and " << nCtrl << " Controls." << std::endl;
        std::cout << numGenes << " analytes/patterns. \n" << NUMPERMUTATIONS << " permutations will be performed for each analyte. \n\n";
        std::cout << "Assumed " << numheadrows << " header rows and " << numheadcols << " header columns in '" << argv[1]
                  << "' and '" << argv[2] << "'.\n";
        std::cout << "\n\n***Important: Assumed each column of these files corresponds to an individual and each row corresponds to an analyte.***\n\n";
        if(testPatterns)
            std::cout << "Assumed that node numbers >= " << numGenes << " represent high expression association, while numbers below represent low expression association in the patterns file.\n\n";
        if(NORMALIZE)
            std::cout << "Assuming data has not been normalized previously (change NORMALIZE in d2d.h if this is not true).\n\n";
        else
            std::cout << "Assuming data has been normalized previously (change NORMALIZE in d2d.h if this is not true).\n\n";

    }
    
    if(USE_YOUJ_SIG) {
        std::cout << "Youden J p-values used for testing significance.\n";
        if(LOG_FILE)
            fprintf(logfile, "Youden J p-values used for testing significance.\n");
    }
    else {
        std::cout << "d2d distances p-values used for testing significance.\n";
        if(LOG_FILE)
            fprintf(logfile, "d2d distances p-values used for testing significance.\n");
    
    }

    if (NUMPERMUTATIONS < 1) 
        fatal("Number of permutations must be at least 1. Check header file.");

    if (LOG_FILE) {
        fprintf(logfile, "\n%d Cases and %d Controls.\n%d analytes/patterns.\n%d permutations will be performed for each analyte.\nAssumed %d header rows and %d header columns in '%s' and '%s'.\n\n\n***Important: Assumed each column of these files corresponds to an individual and each row corresponds to an analyte.***\n\n", nCase, nCtrl, numGenes, NUMPERMUTATIONS, numheadrows, numheadcols, argv[1], argv[2]);
        if(NORMALIZE)
            fprintf(logfile, "Assuming data has not been normalized previously (change NORMALIZE in d2d.h if this is not true).\n\n");
        else
            fprintf(logfile, "Assuming data has been normalized previously (change NORMALIZE in d2d.h if this is not true).\n\n");             
    }
   
    if(LOG_FILE && testPatterns)
        fprintf(logfile, "Assumed that values >= %d represent high expression association, while numbers below represent low expression association in the patterns file.\n\n", numGenes);

    if ((nCase > MAX_NUM_INDIVIDUALS) || (nCtrl > MAX_NUM_INDIVIDUALS))
        fatal("Too many individuals.  Edit header file.");
    if (numGenes > MAX_NUM_ANALYTES)
        fatal("Too many analytes.  Edit header file.");
    if ((nCase < 8) || (nCtrl < 8))
        fatal("Too few individuals");
    if (numGenes < 1)
        fatal("Must have at least one analyte");
        
    // allocate memory for header rows and header columns
    char ***caseHeaderRows, ***ctrlHeaderRows, ***geneHeaderCols;
    
    if(((caseHeaderRows = new char** [numheadrows]) == NULL) || ((ctrlHeaderRows = new char** [numheadrows]) == NULL))
        fatal("Memory not allocated.");
        
    for (int i = 0; i < numheadrows; i++) {
        if(((caseHeaderRows[i] = new char* [nCase]) == NULL) || ((ctrlHeaderRows[i] = new char* [nCtrl]) == NULL))
            fatal("Memory not allocated");
        for (int j = 0; j < nCase; j++)
            if((caseHeaderRows[i][j] = new char [MAX_LABEL_LENGTH]) == NULL)
                fatal("Memory not allocated");
        for (int j = 0; j < nCtrl; j++)
            if((ctrlHeaderRows[i][j] = new char [MAX_LABEL_LENGTH]) == NULL)
                fatal("Memory not allocated");
    }
    
    if((geneHeaderCols = new char** [numGenes]) == NULL) 
        fatal("Memory not allocated.");
        
    for (int i = 0; i < numGenes; i++) {
        if((geneHeaderCols[i] = new char* [numheadcols]) == NULL)
            fatal("Memory not allocated");
        for (int j = 0; j < numheadcols; j++)
            if((geneHeaderCols[i][j] = new char [MAX_LABEL_LENGTH]) == NULL)
                fatal("Memory not allocated");
    }
        
    readHeaderRows(cases, nCase, caseHeaderRows, numheadrows, numheadcols);
    readHeaderRows(ctrls, nCtrl, ctrlHeaderRows, numheadrows, numheadcols);
    
    int minNumSubsetCase = nCase * MINSUBSETPERCENT; //minimum number of individuals in subtype
    int minNumSubsetCtrl = nCtrl * MINSUBSETPERCENT;
    
    if (((float)nCase * MINSUBSETPERCENT) - (int)(nCase * MINSUBSETPERCENT) > TOL) 
        minNumSubsetCase++;

    if (((float)nCtrl * MINSUBSETPERCENT) - (int)(nCtrl * MINSUBSETPERCENT) > TOL) 
        minNumSubsetCtrl++;

    if (minNumSubsetCase < 1)
        minNumSubsetCase = 1; // at least one individual required in a subtype
    if (minNumSubsetCtrl < 1)
        minNumSubsetCtrl = 1; 
        
    if (!QUIET) 
        std::cout << "\nMinimum number of Cases/Controls allowed as a subtype are " << minNumSubsetCase << " / " << minNumSubsetCtrl << ", respectively, (" << MINSUBSETPERCENT*100.0 << "\%).\n\n";            
      
    if (LOG_FILE)
        fprintf(logfile, "\nMinimum percentage of Cases/Controls allowed as a subtype are %d / %d, respectively, (%f\%).\n\n", minNumSubsetCase, minNumSubsetCtrl, MINSUBSETPERCENT);
               
    if (!testPatterns) // test each analyte individually
        testIndAnalytes(numGenes, ctrls, cases, nCtrl, nCase, geneHeaderCols, minNumSubsetCase, minNumSubsetCtrl, sigfile, output, sigFileName, numheadrows, numheadcols); 

    else  // test patterns
        testAllPatterns(numGenes, ctrls, cases, inputPatterns, nCtrl, nCase, geneHeaderCols, minNumSubsetCase, minNumSubsetCtrl, sigfile, output, logfile, numheadcols);
 
    if (0) {
        std::cout << "Header Columns:\n";
        for (int i = 0; i < numGenes; i++) {
            for (int j = 0; j < numheadcols; j++)
                std::cout << geneHeaderCols[i][j] << "  ";
            std::cout << "\n";
        }
        std::cout << "\n";  
    }
    
    for (int i = 0; i < numheadrows; i++) {
        for (int j = 0; j < nCase; j++)
            delete [] caseHeaderRows[i][j];
        for (int j = 0; j < nCtrl; j++)
            delete [] ctrlHeaderRows[i][j];
    }   
    
    for (int i = 0; i < numGenes; i++) {
        for (int j = 0; j < numheadcols; j++) 
            delete [] geneHeaderCols[i][j];
    }         


    t.stop("\nTimer stopped.");
    std::cout << t << " seconds\n" << std::endl;

    double compTime;
    compTime = t.timeVal();

    if (LOG_FILE)
        fprintf(logfile, "\n%f seconds.\n\n", compTime);

    fclose(logfile);
    fclose(sigfile);
    fclose(output);

    return 0;
}



void readHeaderRows(FILE *fileptr, int numInd, char ***headerRows, int numheadrows, int numheadcols) {
    // read in header rows, check for string length and record
    char strng[MAX_LABEL_LENGTH];
    
    for (int i = 0; i < numheadrows; i++) {
        for (int j = 0; j < numheadcols; j++)  // read in strings before data columns begin
            fscanf(fileptr, "%s", strng); 
            
        for (int j = 0; j < numInd; j++) {
            fscanf(fileptr, "%s", strng);
            int k = 0; // walk through string to see if termination symbol exists
            while(k < MAX_LABEL_LENGTH) {
               if (strng[k] == '\0')
                  break; 
               k++;
           }
            
           if (k == MAX_LABEL_LENGTH - 1)
               fatal("Header label exceeds MAX_LABEL_LENGTH, revise header file\n");   
               
           strcpy(headerRows[i][j], strng); // store string information 
        }
    }
        
    if (VERBOSE) {
        std::cout << "Header Rows:\n";
        for (int i = 0; i < numheadrows; i++) {
            for (int j = 0; j < numInd; j++)
                std::cout << headerRows[i][j] << "  ";
            std::cout << "\n";
        }
        
        std::cout << "\n";
    }
}

int readDataRow(FILE *fileptr, int numInd, float *data, char ***headerCols, int currentGene, int numheadcols) {
    // read in one data row, check values for validity, return number of missing values and filled data array
    char strng[MAX_LABEL_LENGTH];
    int numMissing = 0;
    float val;
    int ptr = 0; // pointer for data array
    
    for (int i = 0; i < numInd; i++)
         data[i] = NOTALLOWEDVALUE; // initialize to extreme value (will remain at the end of array for missing values)
    
    for (int i = 0; i < numheadcols; i++) {
         fscanf(fileptr, "%s", strng); // read in header columns
         int k = 0; // walk through string to see if termination symbol exists
         while(k < MAX_LABEL_LENGTH) {
            if (strng[k] == '\0')
               break; 
            k++;
        }
         
        if (k == MAX_LABEL_LENGTH - 1)
            fatal("Header label exceeds MAX_LABEL_LENGTH, revise header file\n");   
            
        strcpy(headerCols[currentGene][i], strng);    
    }

    for (int i = 0; i < numInd; i++) {
        if (feof(fileptr))
            fatal("Input file is missing data");

        fscanf(fileptr, "%s", strng);

        // check for missing value marked as 'NA'
        if ((strncmp(strng, "NA", 2) == 0) || (strncmp(strng, "NN", 2) == 0)) {
            numMissing++;
            data[ptr++] = MAX_EXP + 1; // mark as infinity
            continue;  // done with this entry
        }

        checkValid(strng); // check that string begins with a valid character        
        val = atof(strng);

        if ((val > MAX_EXP) || (val < MIN_EXP)) {
            std::cout << "col " << i+1 << ": " <<  val << std::endl;
            fatal("Invalid expression value in input data.  \n\tCheck MAX_EXP and MIN_EXP in header file.");
        }
        
        data[ptr++] = val;

    }
    
    if (VERBOSE) {
        std::cout << "Data row read:";
        for (int i = 0; i < numInd; i++)
             std::cout << "\t" << data[i];
        std::cout << "\n\n";
    }
    
    return numMissing;
}


float comp2median(float *data, int minNumSubset, int numInd, int numMissing, float *boundaries) {
    // compute minimum 2-median for data and return the distance between the two medians
    
    // allocate memory
    float *left, *right; // hold sum of distances to median for clusters of each size from the left/right sides of the data array
    if (((left = new float [numInd]) == NULL) || ((right = new float [numInd]) == NULL))
        fatal("memory not allocated");

    float *pairwiseDist; // pairwise distances between adjacent values in sorted array
    if ((pairwiseDist = new float [numInd - 1]) == NULL) 
        fatal("memory not allocated");     
        
    float *reverseData; // will hold data sorted in nonincreasing order
    if ((reverseData = new float [numInd]) == NULL) 
        fatal("memory not allocated");     
           
    float incumbent = 10.0 * MAX_EXP; // initialize incumbent solution to extremely high value
    int incumbentLeftSize; // hold the number of nodes in left cluster for current incumbent solution
    float leftMedian, rightMedian; // medians for the left and right clusters, respectively
    int temp;
    
    std::sort(data, data + numInd); // sort data using quicksort
    
    if (VERBOSE) {
        std::cout << "\nSorted data:";
        for (int i = 0; i < numInd; i++)
             std::cout << "\t" << data[i];
        std::cout << "\n\n";
    }    

    for (int i = 0; i < numInd - numMissing - 1; i++) // compute pairwise distances between adjacent values in sorted array
        pairwiseDist[i] = data[i + 1] - data[i];
        
    if (0) {
        std::cout << "Pairwise distances:";
        for (int i = 0; i < numInd - numMissing - 1; i++)
             std::cout << "\t" << pairwiseDist[i];
        std::cout << "\n\n";
    }        

    // populate left array using dynamic programming (see manuscript for details)
    left[0] = NOTALLOWEDVALUE; // this value is not used
    left[1] = 0;
    left[2] = pairwiseDist[0];
    left[3] = pairwiseDist[0] + pairwiseDist[1];
    
    for (int i = 4; i < numInd - numMissing; i++) {
        left[i] = left[i-1]; 
        int stopIter = i/2 + 1; // assuming integer division with fractions truncated
        for (int j = 2; j <= stopIter; j++)
            left[i] += pairwiseDist[i - j];
    }

    if (0) {
        std::cout << "Left array:";
        for (int i = 0; i < numInd - numMissing; i++)
             std::cout << "\t" << left[i];
        std::cout << "\n\n";
    }        
    
    for (int i = 0; i < numInd - numMissing; i++)  
        reverseData[i] = data[numInd - i - numMissing - 1]; // reverse order of sorted data
        
     if (0) {
        std::cout << "Reverse sorted data:";
        for (int i = 0; i < numInd - numMissing; i++)
             std::cout << "\t" << reverseData[i];
        std::cout << "\n\n";
    }    
       
    for (int i = 0; i < numInd - numMissing - 1; i++) // compute pairwise distances between adjacent values in sorted array
        pairwiseDist[i] = reverseData[i] - reverseData[i + 1];
        
    if (0) {
        std::cout << "Pairwise distances:";
        for (int i = 0; i < numInd - numMissing - 1; i++)
             std::cout << "\t" << pairwiseDist[i];
        std::cout << "\n\n";
    }        

    // populate left array using dynamic programming (see manuscript for details)
    right[0] = NOTALLOWEDVALUE; // this value is not used
    right[1] = 0;
    right[2] = pairwiseDist[0];
    right[3] = pairwiseDist[0] + pairwiseDist[1];
    
    for (int i = 4; i < numInd - numMissing; i++) {
        right[i] = right[i-1]; 
        int stopIter = i/2 + 1; // assuming integer division with fractions truncated
        for (int j = 2; j <= stopIter; j++)
            right[i] += pairwiseDist[i - j];
    }

    if (0) {
        std::cout << "Right array:";
        for (int i = 0; i < numInd - numMissing; i++)
             std::cout << "\t" << right[i];
        std::cout << "\n\n";
    }        
    
    for (int i = minNumSubset; i <= numInd - numMissing - minNumSubset; i++) {
        if (0) std::cout << left[i] + right[numInd - i] << "\n";
        if (left[i] + right[numInd - numMissing - i] < incumbent) { // less sum of distances to the two medians than incumbent
            incumbentLeftSize = i;  // record current best cluster pair
            incumbent = left[i] + right[numInd - numMissing - i]; // update incumbent with new sum of distances
        }
    }

    temp = incumbentLeftSize / 2; // integer division, first step to find median of left cluster
    if (incumbentLeftSize % 2 > TOL)  // odd number of nodes in left cluster
        leftMedian = data[temp]; // median is the middle node in the cluster
    
    else  // even number of nodes, so median is between two nodes
        leftMedian = (data[temp - 1] + data[temp]) / 2.0; 
        
    if (VERBOSE)
        std::cout << "Size of left cluster is " << incumbentLeftSize << ". Left median is " << leftMedian << "\t"; 
        
    boundaries[0] = data[incumbentLeftSize - 1]; // record data points on the boundary between the two clusters
    boundaries[1] = data[incumbentLeftSize];
    if(VERBOSE)
        std::cout << "Data values at the cluster boundaries are " << boundaries[0] << " and " << boundaries[1] << ".\n";
    
    temp = numInd - numMissing - incumbentLeftSize; // number of individuals in right cluster (first step to find median of right cluster)
    if (temp % 2 > TOL)  // odd number of nodes in right cluster
        rightMedian = reverseData[temp / 2]; // median is the middle node in the cluster
    
    else  // even number of nodes, so median is between two nodes
        rightMedian = (reverseData[(temp/2) - 1] + reverseData[temp / 2]) / 2.0; 
        
    if (VERBOSE)
        std::cout << "Size of right cluster is " << temp << ". Right median is " << rightMedian << "\n"; 

    delete [] left;
    delete [] right;
    delete [] reverseData;
    delete [] pairwiseDist;

    return rightMedian - leftMedian;
}



float comp_odds_ratio(float *caseData, float *ctrlData, int nCase, int nCtrl, int numMissingCase, int numMissingCtrl, float *boundaries, float *oddsratio, int *tallies, float *youJ) {
    
    float thresh; // will hold threshold between the two clusters
    float nCaseWith, nCtrlWith, nCaseWO, nCtrlWO; // numbers of cases/controls with/without levels beyond the threshold
    float temp, logOR; // temporary variables

    nCaseWith = nCtrlWith = 0; // initialization
    oddsratio[0] = oddsratio[1] = oddsratio[2] = -1.0;
    oddsratio[3] = 1.0; // initialize to risk associated with high expression

    thresh = (boundaries[0] + boundaries[1]) / 2.0; // midpoint between the two cluster boundaries
    if (VERBOSE) 
        std::cout << "Threshold = " << thresh << ".\n";
        
    // first check odds ratio for high values being associated
    for (int i = 0; i < nCase - numMissingCase; i++)
        if (caseData[i] > thresh - TOL) // greater than or equal to
            nCaseWith++;
            
    for (int i = 0; i < nCtrl - numMissingCtrl; i++)
        if (ctrlData[i] > thresh - TOL) // greater than or equal to
            nCtrlWith++;

    nCaseWO = (float) (nCase - nCaseWith - numMissingCase);
    nCtrlWO = (float) (nCtrl - nCtrlWith - numMissingCtrl);
    
    if(VERBOSE) {
        std::cout << nCaseWith << " and " << nCtrlWith << " Cases and Controls with high expression, respectively.\n";
        std::cout << nCaseWO << " and " << nCtrlWO << " Cases and Controls with low expression, respectively.\n";
    }

    if ((nCaseWO > TOL) && (nCtrlWith > TOL)) // no zero in denominator
        oddsratio[0] = (nCaseWith * nCtrlWO) / (nCtrlWith * nCaseWO); // compute odds ratio

    // check to see if risk association is with low values instead
    if((oddsratio[0] < 1.0) && (oddsratio[0] > 0 - TOL)) { // if so, swap values
        oddsratio[0] = 1.0 / oddsratio[0]; // invert odds ratio and swap to numbers for low expression
        temp = nCaseWith;
        nCaseWith = nCaseWO;
        nCaseWO = temp;
        temp = nCtrlWith;
        nCtrlWith = nCtrlWO;
        nCtrlWO = temp;    
        oddsratio[3] = -1; // set flag for low expression
    }

    if (oddsratio[0] < 0 - TOL) { // odds ratio isn't defined, check to see if high expression is protective
        if ((float)nCaseWith / (float)(nCase - numMissingCase) < (float)nCtrlWith / (float)(nCtrl - numMissingCtrl)) {
            oddsratio[3] = -1; // flip to low expression so as to have risk rather than protective
            temp = nCaseWith;
            nCaseWith = nCaseWO;
            nCaseWO = temp;
            temp = nCtrlWith;
            nCtrlWith = nCtrlWO;
            nCtrlWO = temp;            
        }       
    }

/*            
    if (oddsratio[0] < 0 - TOL) { // odds ratio isn't defined
        if (nCaseWith > nCaseWO) { // more cases with high expression
            oddsratio[3] = -1; // assume subtype is minority of cases
            temp = nCaseWith;
            nCaseWith = nCaseWO;
            nCaseWO = temp;
            temp = nCtrlWith;
            nCtrlWith = nCtrlWO;
            nCtrlWO = temp;    
        }
        
        else  // more cases with low expression, so assume high expression is subtype
            oddsratio[3] = 1;
    }
*/
 
    
    tallies[0] = nCaseWith; // record tallies for printing out
    tallies[1] = nCaseWO;
    tallies[2] = nCtrlWith;
    tallies[3] = nCtrlWO;    

    // compute 95% confidence interval
    if ((nCaseWith > TOL) && (nCtrlWith > TOL)) 
        if ((nCaseWO > TOL) && (nCtrlWO > TOL)) { // no zero in denominators
            // calculate 95% confidence interval
            temp = sqrt(1.0 / nCaseWith + 1.0 / nCaseWO + 1.0 / nCtrlWith + 1.0 / nCtrlWO);
            temp *= -1.96; // negate and multiply by constant for 95% interval
            logOR = log(oddsratio[0]); // find the natural log of the odds ratio
            temp += logOR;
            oddsratio[1] = exp(temp); // lower threshold on confidence interval

            temp = sqrt(1.0 / nCaseWith + 1.0 / nCaseWO + 1.0 / nCtrlWith + 1.0 / nCtrlWO);
            temp *= 1.96; // multiply by constant for 95% interval
            logOR = log(oddsratio[0]); // find the natural log of the odds ratio
            temp += logOR;
            oddsratio[2] = exp(temp); // upper threshold on confidence interval
        }
        
    // compute Youden's J statistic
    *youJ = ((float)nCaseWith / (float)(nCaseWith + nCaseWO)) - (nCtrlWith / (float)(nCtrlWith + nCtrlWO));

    if (VERBOSE) {
        std::cout << "\n\t**Youden's J = " << *youJ << ", odds ratio = " << oddsratio[0] << ", 95\% CI: [" << oddsratio[1] << ", " << oddsratio[2] << "].\n";
        if(oddsratio[3] > 0 + TOL)
            std::cout << "\tHigh expression is associated with risk.\n\n";
        else 
            std::cout << "\tLow expression is associated with risk.\n\n";
    }
    
    if (*youJ < (0.0 - TOL))
      fatal("Protective association observed. Code needs updates to handle this situation.");
             
    return thresh;
}



float comp_pval(float *caseData, float *ctrlData, int minNumSubsetCase, int minNumSubsetCtrl, int nCase, int nCtrl, int numMissingCase, int numMissingCtrl, float diffCaseCtrl, float thresh, int moreOrLess, float youJ, float *pvalYouJ) {
// compute p-value by running permutation trials in which Case/Control labels are randomly assigned

    // allocate data arrays
    float *randCase, *randCtrl; // hold randomized expression values
    if (((randCase = new float [nCase]) == NULL) || ((randCtrl = new float [nCtrl]) == NULL))
        fatal("memory not allocated");

    float *randDist; // hold distances for each random trial
    if ((randDist = new float [NUMPERMUTATIONS]) == NULL)
        fatal("memory not allocated");
        
    float *randYouJ; // hold Youden J value for each random trial
    if ((randYouJ = new float [NUMPERMUTATIONS]) == NULL)
        fatal("memory not allocated");
        
    float pval; // p-value to be computed
    int casePtr, ctrlPtr; // point to position in random case/control arrays
    int randVal; // binary random value
    float distCase, distCtrl; // distances between medians for randomized cases/controls
    float boundaries[2]; // dummy values
    int temp; 
    
    srand(time(NULL)); // set random seed
    //std::cout << rand() << std::endl;
    
    nCase -= numMissingCase; // adjust for missing individuals
    nCtrl -= numMissingCtrl; 

    for (int perm = 0; perm < NUMPERMUTATIONS; perm++) {
        casePtr = ctrlPtr = 0; // initialize pointers to beginning of arrays
        
        for (int j = 0; j < nCase; j++) {
            randVal = (rand() + j) % 2; // 0 to assign to cases, 1 to assign to controls
            //std::cout << randVal << "\n";
            if ((randVal == 0) && (casePtr == nCase))
                randVal = 1; // assign to controls array as case array is filled
            if ((randVal == 1) && (ctrlPtr == nCtrl))
                randVal = 0; // assign to cases array as control array is filled
                
            if (randVal == 0) 
                randCase[casePtr++] = caseData[j];
            if (randVal == 1) 
                randCtrl[ctrlPtr++] = caseData[j];
        }
    
        for (int j = 0; j < nCtrl; j++) {
            randVal = (rand() + j) % 2; // 0 to assign to cases, 1 to assign to controls
            //std::cout << randVal << "\n";
            if ((randVal == 0) && (casePtr == nCase))
                randVal = 1; // assign to controls array as case array is filled
            if ((randVal == 1) && (ctrlPtr == nCtrl))
                randVal = 0; // assign to cases array as control array is filled
                
            if (randVal == 0) 
                randCase[casePtr++] = ctrlData[j];
            if (randVal == 1) 
                randCtrl[ctrlPtr++] = ctrlData[j];
        }
   
        if (VERBOSE) {
            std::cout << "Random Cases:";
            for (int i = 0; i < nCase; i++)
                 std::cout << "\t" << randCase[i];
            std::cout << "\n";
            std::cout << "Random Controls:";
            for (int i = 0; i < nCtrl; i++)
                 std::cout << "\t" << randCtrl[i];
            std::cout << "\n";

        }        

        distCase = comp2median(randCase, minNumSubsetCase, nCase, 0, boundaries); 
        
        if (0)
            std::cout << "Distance between medians for random cases is " << distCase << ".\n";

        distCtrl = comp2median(randCtrl, minNumSubsetCtrl, nCtrl, 0, boundaries);
        
        if (0)
            std::cout << "Distance between medians for random controls is " << distCtrl << ".\n";

        randDist[perm] = distCase - distCtrl;
        
        if (VERBOSE)
            std::cout << "Difference in distances for random trial is " << randDist[perm] << ".\n";
       
        // compute Youden's J statistic
        temp = 0; // first count cases with pattern
        for (int i = 0; i < nCase; i++) 
            if (randCase[i] > NOTALLOWEDVALUE - TOL) { //not missing data
                if(moreOrLess > 0) { // subset values are greater than threshold
                    if(randCase[i] >= thresh - TOL) // this value is in subset
                        temp++;
                }
                else {
                    if(randCase[i] < thresh) // this value is in subset
                        temp++;
                }             
            }
        randYouJ[perm] = (float)temp / (float)nCase; // store percentage of cases in subset
        
        temp = 0; // now count controls with pattern
        for (int i = 0; i < nCtrl; i++) 
            if (randCtrl[i] > NOTALLOWEDVALUE - TOL) { //not missing data
                if(moreOrLess > 0) { // subset values are greater than threshold
                    if(randCtrl[i] >= thresh - TOL) // this value is in subset
                        temp++;
                }
                else {
                    if(randCtrl[i] < thresh) // this value is in subset
                        temp++;
                }             
            }
        randYouJ[perm] -= (float)temp / (float)nCtrl; // subtract percentage of controls to get Youden's J statistic       
    
        if (VERBOSE)
            std::cout << "Youden's J for random trial is " << randYouJ[perm] << ".\n\n";   
    }
    
    std::sort(randDist, randDist + NUMPERMUTATIONS); // sort data using quicksort
    std::sort(randYouJ, randYouJ + NUMPERMUTATIONS);

    if (VERBOSE) {
        std::cout << "Sorted differences between bicluster distances from random trials:";
            for (int i = 0; i < NUMPERMUTATIONS; i++)
                std::cout << "\t" << randDist[i];
            std::cout << "\n";
    
        std::cout << "Sorted Youden J values from random trials:";
            for (int i = 0; i < NUMPERMUTATIONS; i++)
                std::cout << "\t" << randYouJ[i];
            std::cout << "\n";
    }
    
    // compute p-val for d2d
    temp = 0; // point to lowest difference in permutation trials
    // walk up through permutation trials until find one that is better than original solution
    while ((randDist[temp] < diffCaseCtrl) && (temp < NUMPERMUTATIONS)) 
        temp++;
    pval = (float)(NUMPERMUTATIONS - temp) / (float)NUMPERMUTATIONS;
    
    // compute p-val for Youden's J
    temp = 0; // point to lowest difference in permutation trials
    // walk up through permutation trials until find one that is better than original solution
    while ((randYouJ[temp] < youJ) && (temp < NUMPERMUTATIONS)) 
        temp++;
    *pvalYouJ = (float)(NUMPERMUTATIONS - temp) / (float)NUMPERMUTATIONS;    
        
    delete [] randCase;
    delete [] randCtrl;
    delete [] randDist;
    delete [] randYouJ;

    return pval; 
}



bool is_significant(float pval, float *oddsratio, float pvalYouJ) {

    int sig = 0; 
    
    if (!USE_YOUJ_SIG) 
      if (pval <= PVAL_THRESH + TOL)
        sig++;
    
    if (USE_YOUJ_SIG)
      if (pvalYouJ <= PVAL_THRESH + TOL)
        sig++;
        
    
    /*  
    if (oddsratio[0] < 0) // undefined, so include in signifcant list
        sig++;
    
    // only test for 95% confidence interval entirely above 1 as only looking for risk analytes  
    if ((oddsratio[1] >= 1.0 - TOL) && (oddsratio[2] >= 1.0 - TOL))
        sig++;
    */
    
    if (sig > 0 + TOL)
        return true;
    else
        return false;
}



void printIndfile(FILE *cases, FILE *ctrls, FILE *sigfile, FILE *indFile, int nCase, int nCtrl, int numGenes, int numheadrows, int numheadcols) {
 
    char strng[MAX_LABEL_LENGTH];
    int rowNum = 0; // row number for next significant gene
    int rowCount = 0; // count current number of rows read in 
    char sign[2]; // hold < or > sign (using a pointer to a string to enable fscanf to ignore white space)
    float thresh; // hold threshold value
    float val; // hold current expression value
    char **caseIDs, **ctrlIDs; // hold case and control IDs 
    
    //if (VERBOSE)
        //std::cout << "\nAssuming individuals' IDs are in row " << IND_ID_ROW << ". (This value can be changed in the header file.)\n\n";
    
    // allocate memory
    if(((caseIDs = new char* [nCase]) == NULL) || ((ctrlIDs = new char* [nCtrl]) == NULL))
        fatal("Memory not allocated.");
    for (int i = 0; i < nCase; i++)
        if((caseIDs[i] = new char [MAX_LABEL_LENGTH]) == NULL)
            fatal("Memory not allocated.");
    for (int i = 0; i < nCtrl; i++)
        if((ctrlIDs[i] = new char [MAX_LABEL_LENGTH]) == NULL)
            fatal("Memory not allocated.");
    
    
    for (int i = 0; i < numheadrows; i++) {  // read in header rows in cases and controls files
        for (int j = 0; j < numheadcols; j++) { // read in strings before data columns begin
            fscanf(cases, "%s", strng); 
            fscanf(ctrls, "%s", strng);
        }
          
        // save individuals' IDs and ignore other header rows 
        for (int j = 0; j < nCase; j++) {
            if(i == IND_ID_ROW - 1) 
                fscanf(cases, "%s", caseIDs[j]);

            else
                fscanf(cases, "%s", strng);
        }
        
        for (int j = 0; j < nCtrl; j++) {
            if(i == IND_ID_ROW - 1)
                fscanf(ctrls, "%s", ctrlIDs[j]);
            else
                fscanf(ctrls, "%s", strng);
        }
    } 
    
    if (0) {
        std::cout << "Case IDs: ";
        for (int i = 0; i < nCase; i++) 
            std::cout << caseIDs[i] << " ";
        std::cout << "\nControl IDs: ";
        for (int i = 0; i < nCtrl; i++) 
            std::cout << ctrlIDs[i] << " ";
        std::cout << "\n";
        
    }

    for (int i = 0; i < NUM_STRINGS_INFO_SIG_FILE; i++) // read in and ignore first sentence in file
        fscanf(sigfile, "%s", strng);

    for (int i = 0; i < 1+numheadcols; i++) { // header row in .sig file has one more column than original data file (for row number)
        fscanf(sigfile, "%s", strng);  
        fprintf(indFile, "%s\t", strng);
    }
   
    for (int i = 0; i < NUM_STATS_SIG_FILE; i++)  // read in the rest of the header row from significant file and ignore
        fscanf(sigfile, "%s", strng);  
        
    fprintf(indFile, "Individuals with associated expression:\n");
   
    // read in each significant analyte and write out individuals to indFile
    while(!feof(sigfile)) {
        fscanf(sigfile, "%s", strng); // read in row number for next significant gene
        if(feof(sigfile)) // check for end of file missed due to extra white space
            break;
        
        rowNum = atoi(strng);
        //std::cout << "sig row number: " << rowNum << "\n";
        
        for (int i = 0; i < rowNum - 1 - rowCount; i++) { // read in and ignore data until get to significant row
            for (int j = 0; j < numheadcols+nCase; j++) 
                fscanf(cases, "%s", strng);
            for (int j = 0; j < numheadcols+nCtrl; j++) 
                fscanf(ctrls, "%s", strng);            
        }
        
        rowCount = rowNum; // update to use on next iteration of this loop
        
        // print analyte info to individuals' file
        fprintf(indFile, "%d\t", rowNum); 
        for (int i = 0; i < numheadcols; i++) { // read in analyte info from significant file and print to individuals' file
            fscanf(sigfile, "%s", strng);  
            fprintf(indFile, "%s\t", strng);
        }
        
        fscanf(sigfile, "%s", strng); // read in pvalue and ignore
        fscanf(sigfile, "%s", sign); // read in sign
        
        if ((sign[0] != '<') && (sign[0] != '>'))
            fatal("Error reading in sign for threshold in .sig file");
        fscanf(sigfile, "%s", strng); // read in threshold value
        
        
        checkValid(strng); // check that strng starts with a number
        thresh = atof(strng); // record threshold
        
        //std::cout << "\n  associated if " << sign << thresh << "\n";
                
        if(VERBOSE)
            std::cout << "Threshold for analyte " << rowNum <<  " is " << sign[0] << thresh <<".\n";
            
        for (int j = 0; j < numheadcols; j++) // read in and ignore header columns in data files
            fscanf(cases, "%s", strng);
        for (int j = 0; j < numheadcols; j++) 
            fscanf(ctrls, "%s", strng); 
        
        for (int i = 0; i < nCase; i++) {  // read in cases analyte values and compare with threshold
            fscanf(cases, "%s", strng); // read in expression value
            
            if ((strncmp(strng, "NA", 2) == 0) || (strncmp(strng, "NN", 2) == 0)) //missing data, so continue
                continue;  
                
            checkValid(strng);
            val = atof(strng);
            //std::cout << "val = " << val << "\n";
            
            if (sign[0] == '<') { // less than (use strictly less than)
                if (val < thresh)
                    fprintf(indFile, "Case_%d: %s\t", i+1, caseIDs[i]);
            }
            
            if (sign[0] == '>') { // greater than (use greater than or equal to)
                if (val > thresh - TOL)
                    fprintf(indFile, "Case_%d: %s\t", i+1, caseIDs[i]);            
            }
            
        }
        
        for (int i = 0; i < nCtrl; i++) {  // read in controls analyte values and compare with threshold
            fscanf(ctrls, "%s", strng); // read in expression value
            
            if ((strncmp(strng, "NA", 2) == 0) || (strncmp(strng, "NN", 2) == 0)) //missing data, so continue
                continue; 
            checkValid(strng);
            val = atof(strng);
            //std::cout << "val = " << val << "\n";
            
            if (sign[0] == '<') { // less than (use strictly less than)
                if (val < thresh)
                    fprintf(indFile, "Ctrl_%d: %s\t", i+1, ctrlIDs[i]);
            }
            
            if (sign[0] == '>') { // greater than (use greater than or equal to)
                if (val > thresh - TOL)
                    fprintf(indFile, "Ctrl_%d: %s\t", i+1, ctrlIDs[i]);            
            }
            
        }

        for (int i = 0; i < NUM_STATS_SIG_FILE - 2; i++) { 
            fscanf(sigfile, "%s", strng); // read in and ignore percentages, odds ratio, and Youden's J values
            //std::cout << "\n" << strng << "\n";
        } 
            
        fprintf(indFile, "\n");
    }

}



void checkValid(char *strng) {  // checks string to see if it starts with a valid character for a float
    int ascii;
    int digit = 0;

    while (strng[digit] != '\0') { // check each digit
        ascii = (int) strng[digit]; // ascii value of next character
        if ((ascii < 48) || (ascii > 57)) { // not a digit
            if ((ascii != 45) && (ascii != 46)) { // not a '-' or '.'
                std::cout << strng << std::endl;
                fatal("Invalid expression value in input file");
            }
        }
        digit++;
    }
}



void testIndAnalytes(int numGenes, FILE *ctrls, FILE *cases, int nCtrl, int nCase, char ***geneHeaderCols, int minNumSubsetCase, int minNumSubsetCtrl, FILE *sigfile, FILE *output, char *sigFileName, int numheadrows, int numheadcols) {  // test each analyte individually

    int numMissingCase, numMissingCtrl; // will hold number of missing values in data arrays
    float distCase; // distance between medians for Cases
    float distCtrl; // distance between medians for Controls
    float diffCaseCtrl; // difference between the distances (distCase - distCtrl)
    float pval; // p-value
    float boundaries[2]; // hold the two values bordering the boundary between the 2 clusters
    float thresh; // threshold between clusters (mean between the largest value in cluster 1 and the smallest in cluster 2)
    float youJ; // Youden's J statistic
    float pvalYouJ; // p-value for Youden's J statistic
    float oddsratio[4]; // hold odds ratio and the 95% confidence interval values, plus flag for < or > for the threshold
    int tallies[4]; // tallies of individuals with/without associated expression for each group (case/control)
    float percentCase, percentCtrl; // percentage of each group with associated expression
    bool significant; // flag to mark significant analytes
    char strng[MAX_LABEL_LENGTH*MAX_LABEL_LENGTH]; // temporary string 

    // allocate data arrays
    float *caseData, *ctrlData; // hold expression values
    if (((caseData = new float [nCase]) == NULL) || ((ctrlData = new float [nCtrl]) == NULL))
        fatal("memory not allocated");
    
    // loop through analytes and compute p-values and odds ratios   
    for (int i = 0; i < numGenes; i++) { // read in and analyze each analyte
        if (VERBOSE)
            std::cout << "\n\n**Analyte " << i+1 << "**\n";
            
        numMissingCtrl = readDataRow(ctrls, nCtrl, ctrlData, geneHeaderCols, i, numheadcols); // read next line of data in Controls file
        distCtrl = comp2median(ctrlData, minNumSubsetCtrl, nCtrl, numMissingCtrl, boundaries);
        if (VERBOSE)
            std::cout << "Distance between medians for Controls is " << distCtrl << ".\n";
        
        numMissingCase = readDataRow(cases, nCase, caseData, geneHeaderCols, i, numheadcols); // read next line of data in Cases file
        distCase = comp2median(caseData, minNumSubsetCase, nCase, numMissingCase, boundaries); 
        if (VERBOSE)
            std::cout << "Distance between medians for Cases is " << distCase << ".\n";
            
        diffCaseCtrl = distCase - distCtrl;
        if (VERBOSE)
            std::cout << "Difference in distances is " << diffCaseCtrl << ".\n\n";
        
        // compute threshold and odds ratio
        thresh = comp_odds_ratio(caseData, ctrlData, nCase, nCtrl, numMissingCase, numMissingCtrl, boundaries, oddsratio, tallies, &youJ);
        percentCase = (float)tallies[0] / (float)(tallies[0] + tallies[1]);
        percentCtrl = (float)tallies[2] / (float)(tallies[2] + tallies[3]);
                
        // compute the p-value    
        pval = comp_pval(caseData, ctrlData, minNumSubsetCase, minNumSubsetCtrl, nCase, nCtrl, numMissingCase, numMissingCtrl, diffCaseCtrl, thresh, oddsratio[3], youJ, &pvalYouJ);       
        if (VERBOSE) 
            std::cout << "Analyte " << i+1 << " has d2d p-value of " << pval << " and Youden J p-value of " << pvalYouJ << ".\n";
 
        if (SIG_FILE)
            significant = is_significant(pval, oddsratio, pvalYouJ);    
        
        if (SIG_FILE && significant) {
            fprintf(sigfile, "%d\t", i+1);  
            for (int j = 0; j < numheadcols; j++)
                fprintf(sigfile, "%s\t", geneHeaderCols[i][j]);  
            fprintf(sigfile, "%.4f\t", pval);  
            if(oddsratio[3] > 0) // high expression
                fprintf(sigfile, "> ");
            else if(oddsratio[3] < 0) // low expression
                fprintf(sigfile, "< ");
            fprintf(sigfile, "%.3f\t%d(%.1f\%)\t%d(%.1f\%)\t", thresh, tallies[0], percentCase*100, tallies[2], percentCtrl*100);             
            if(oddsratio[0] < 0) // undefined odds ratio
                fprintf(sigfile, "nan(nan,nan) ");
            else
                fprintf(sigfile, "%.3f(%.3f,%.3f)\t", oddsratio[0], oddsratio[1], oddsratio[2]);    
            fprintf(sigfile, "%.3f\t%.5f\n", youJ, pvalYouJ);        
        }
   
        fprintf(output, "%d\t", i+1); 
        for (int j = 0; j < numheadcols; j++)
            fprintf(output, "%s\t", geneHeaderCols[i][j]);           
        fprintf(output, "%.4f\t", pval); 
        if(oddsratio[3] > 0) // high expression
            fprintf(output, ">");
        else if(oddsratio[3] < 0) // low expression
            fprintf(output, "<");
        fprintf(output, "%.3f\t%d(%.1f\%)\t%d(%.1f\%)\t", thresh, tallies[0], percentCase*100, tallies[2], percentCtrl*100);             
        if(oddsratio[0] < 0) // undefined odds ratio
            fprintf(output, "nan(nan,nan)\t");
        else
            fprintf(output, "%.3f(%.3f,%.3f)\t", oddsratio[0], oddsratio[1], oddsratio[2]);  
        fprintf(output, "%.3f\t%.5f\n", youJ, pvalYouJ);       
    }  // end of read in and analyze each analyte loop

    // check for end of files
    if (!feof(cases)) {
        fscanf(cases, "%s", strng);
        if (!feof(cases))
            fatal("Unread data in Cases input file");
    }

    if (!feof(ctrls)) {
        fscanf(ctrls, "%s", strng);
        if (!feof(ctrls))
            fatal("Unread data in Controls input file");
    }
    
    //print out individuals with the associated expression
    if (SIG_FILE) {
        char sigIndFileName[FILENAMELENGTH]; // hold filename
        const char indSuffix[] = ".ind"; 
        sprintf(sigIndFileName, "%s%s", sigFileName, indSuffix); // string together file name for holding lists of individuals
        FILE *indFile; 
        if ((indFile = fopen(sigIndFileName, "w")) == NULL)
            fatal("File for listing individuals could not be opened.\n");

        fclose(sigfile); // close file with significant analytes listed
        if ((sigfile = fopen(sigFileName, "r")) == NULL) // reopen file in reading mode
            fatal("File listing significant analytes could not be read.");
            
        rewind(cases); // start reading from the beginning
        rewind(ctrls);
        
        printIndfile(cases, ctrls, sigfile, indFile, nCase, nCtrl, numGenes, numheadrows, numheadcols); 
        fclose(indFile);
        
        if (!QUIET)
          std::cout << "\nIDs listed in row " << IND_ID_ROW << " of the input data files were used to print out individuals with associated expression to '" << sigIndFileName <<"'.\n\n";
    }
    
    delete [] caseData;
    delete [] ctrlData;
    
    fclose(cases);
    fclose(ctrls);
}


void testAllPatterns(int numGenes, FILE *ctrls, FILE *cases, FILE *patterns, int nCtrl, int nCase, char ***geneHeaderCols, int minNumSubsetCase, int minNumSubsetCtrl, FILE *sigfile, FILE *output, FILE *logfile, int numheadcols) {  // test entire patterns
    char strng[MAX_LABEL_LENGTH+MAX_LABEL_LENGTH]; // temporary string 
    int numClusters = -1; // number of clusters
    int numSingle = 0; // number of singletons
    int startZero = 0; // set to 1 if start cluster numbers start at 0
    int numStates = 2 * numGenes; // number of states over all of the genes
    int **clusts; // hold analyte states for each cluster
    int *clustSize; // hold number of analytes for each cluster
    int maxClustSize = 0; // record maximum cluster size
    int numMax = 0; // record number with maximum size
    int numInd = nCase + nCtrl; // total number of individuals
    float **data; // hold expression values
    int numMissing; // number of missing values in input data (both files)

   // count number of patterns and count number of singletons
    fscanf(patterns, "%s", strng); // read in number of nodes
    int num = atoi(strng);
    if (num != numGenes * 2)
      fatal("Number of nodes in cluster file not equal to 2 times the number of genes");
  
    for (int i = 0; i < NUM_STRNGS_HEAD_BFS-1; i++) {
      fscanf(patterns,"%s",strng); // read in and throw away header information
      //cout << strng << endl;
    }
  
    if (!strncmp(strng, "edges", 5) == 0) // check text
      fatal("Expected the word edges at end of header of patterns file");
  
    // find the number of clusters and count singletons
    for (int i = 0; i < numStates; i++) {
        fscanf(patterns, "%s", strng); // read in cluster numbers
        num = atoi(strng);
        if (num < -1)
            fatal("community number is less than -1");
        if (num == -1)
            numSingle++; // a singleton

        if (num == 0) {
            startZero = 1; // cluster numbering starts at zero
            if (!strncmp(strng, "0", 1) == 0)  // check to be sure it is a zero
                fatal("Invalid value in community file");
        }

        if (num > numGenes * 2) //
            fatal("invalid community number in input file");

        if (num > numClusters)
            numClusters = num; // find largest cluster number
    }

    if (startZero)
        numClusters++; // cluster numbers start with a zero

    if (!QUIET)
        std::cout << numClusters << " patterns to be tested." << std::endl;
        
    if (LOG_FILE)
        fprintf(logfile, "%d patterns to be tested.\n", numClusters);

    rewind(patterns);
    
    // allocate memory for cluster information
    if ((clusts = new int *[numClusters]) == NULL)
        fatal("Memory not allocated");

    // max number of alleles in a cluster is limited to MAX_SIZE
    for (int i = 0; i < numClusters; i++)
        if ((clusts[i] = new int[MAX_SIZE]) == NULL) // limit size of cluster tested
            fatal("Memory not allocated");

    if ((clustSize = new int[numClusters]) == NULL)
        fatal("Memory not allocated");

    for (int i = 0; i < numClusters; i++)
        for (int j = 0; j < MAX_SIZE; j++)
            clusts[i][j] = -1; // initialize clusts matrix

    for (int i = 0; i < numClusters; i++)
        clustSize[i] = 0; // initialize cluster sizes

    for (int i = 0; i < NUM_STRNGS_HEAD_BFS; i++) 
      fscanf(patterns,"%s",strng); // read in and throw away header information
    if (!strncmp(strng, "edges", 5) == 0) // check text
        fatal("Expected the word edges at end of header of patterns file");

    for (int i = 0; i < numStates; i++) {
        fscanf(patterns, "%s", strng); // read in cluster numbers
        num = atoi(strng);
        if (num > -1) { // not a singleton
            if (clustSize[num] == MAX_SIZE) { // already have maximum number of nodes
                warning("\n\nPattern has more analytes than MAX_SIZE and additional analytes are being ignored.\nMAX_SIZE can be increased in header file.\n\n");
                continue; // ignore additional nodes
            }
            clusts[num][clustSize[num]] = i; // state i is in this cluster
            clustSize[num]++; // increase the number of analytes in this cluster
        }
    }
  
    for (int i = 0; i < numClusters; i++) {
        if (clustSize[i] == 0)
            warning("community with no nodes in communities file");
        if (clustSize[i] == 1)
            numSingle++; // a singleton that wasn't marked '-1'
        if (clustSize[i] > maxClustSize)
            maxClustSize = clustSize[i];
        if (clustSize[i] == MAX_SIZE)
            numMax++;
    }

    std::cout << numSingle << " singletons in patterns file." << std::endl;
    std::cout << "Largest pattern has " << maxClustSize << " analyte states.\n" << std::endl;

    if (numMax > 0) {
        std::cout << numMax << " patterns have more than " << MAX_SIZE << " analyte states." << std::endl;
        std::cout << "Only the first " << MAX_SIZE << " were tested for these patterns.\n" << std::endl;

        if (LOG_FILE)
            fprintf(logfile,
                    "%d patterns have more than %d analyte states.\nOnly the first %d were tested for these patterns.\n\n",
                    numMax, MAX_SIZE, MAX_SIZE);
    }

    if (LOG_FILE)
        fprintf(logfile, "%d singletons in patterns file.\nLargest pattern has %d analyte states.\n\n", numSingle,
                maxClustSize);

    if (VERBOSE) {
        std::cout << "Patterns: " << std::endl;
        for (int i = 0; i < numClusters; i++) {
            for (int j = 0; j < clustSize[i]; j++)
                std::cout << clusts[i][j] << " ";
            std::cout << "\n" ;
        }
    }
  
    fclose(patterns);
      
    // allocate data matrix memory 
    if ((data = new float *[numGenes]) == NULL)
        fatal("memory not allocated");
    for (int i = 0; i < numGenes; i++)
        if ((data[i] = new float[numInd]) == NULL)
            fatal("memory not allocated");

    // set data values to '0', indicating no expression
    for (int i = 0; i < numGenes; i++)
        for (int j = 0; j < numInd; j++)
            data[i][j] = '0'; // initialize to not expressed state

    numMissing = readData(data, geneHeaderCols, numGenes, nCase, nCtrl, ctrls, cases, numheadcols); 
    if(!QUIET) 
        std::cout << numMissing << " missing data values in input files.\n\n";
    if (LOG_FILE)
        fprintf(logfile, "%d missing data values in input files.\n\n", numMissing);   
    
    // compute d2d values 
    comp_d2d(data, geneHeaderCols, numGenes, nCase, nCtrl, numClusters, clusts, clustSize, geneHeaderCols, minNumSubsetCase, minNumSubsetCtrl, sigfile, logfile, output, numheadcols);
    
    for (int i = 0; i < numGenes; i++)
        delete [] data[i];
        
    delete [] data;
}



int readData(float **data, char ***labels, int numGenes, int nCase, int nCtrl, FILE *ctrls, FILE *cases, int numheadcols) {
    int numMissing = 0; // number of missing values for both input files
    float val; // value read in
    int ascii; // temporary storage for ascii value
    char strng[MAX_LABEL_LENGTH]; // temporary string

    // read in data 
    for (int i = 0; i < numGenes; i++) {
        //  read cases data first
        for (int j = 0; j < numheadcols; j++) {
            fscanf(cases, "%s", strng); // read in header columns

            int k = 0; // walk through string to avoid overflow
            while(k < MAX_LABEL_LENGTH) {
              labels[i][j][k] = strng[k];
              if (strng[k] == '\0')
                break; 
              k++;
            }
        }

        for (int j = 0; j < nCase; j++) {
            if (feof(cases)) {
                std::cout << "Analyte " << i+1 << ", Case " << j+1 << " already read.\n";
                fatal("Cases input file is missing data");
            }

            fscanf(cases, "%s", strng);

            // check for missing value marked as 'N' (NN, NA, NaN)
            if (strncmp(strng, "N", 1) == 0) {
                data[i][j] = MAX_EXP + 1; // higher than max incoming data value used to mark missing data
                numMissing++;
                continue;  // done with this entry
            }

            val = atof(strng);

            // check that strng holds a number
            ascii = (int) strng[0]; // ascii value of first character

            if ((ascii < 48) || (ascii > 57)) { // not a digit
                if ((ascii != 45) && (ascii != 46)) { // not a '-' or '.'
                    std::cout << strng << std::endl;
                    fatal("Invalid expression value in Cases data file");
                }
            }

            if ((val > MAX_EXP) || (val < MIN_EXP)) {
                std::cout << val << std::endl;
                fatal("Invalid expression value in Cases data.  \n\tCheck MAX_EXP and MIN_EXP in header file.");
            }
            
            data[i][j] = val; // record value
        } 
    } // end reading cases data
        
    // read in data for controls
    for (int i = 0; i < numGenes; i++) {
        for (int j = 0; j < numheadcols; j++) {
            fscanf(ctrls, "%s", strng); // read in header columns
            
            int k = 0; // count characters 
            while(k < MAX_LABEL_LENGTH) {
              if (strng[k] == '\0')
                break; 
              k++;
            }
            
            if(strncmp(strng, labels[i][j], k) != 0)
              fatal("Header column strings in Cases and Controls files do not match.");
        }

        for (int j = 0; j < nCtrl; j++) {
            if (feof(ctrls))
                fatal("Controls input file is missing data");

            fscanf(ctrls, "%s", strng);

            // check for missing value marked as 'N'
            if (strncmp(strng, "N", 1) == 0) {
                data[i][j + nCase] = MAX_EXP + 1; // higher than max incoming data value used to mark missing data
                numMissing++;
                continue;  // done with this entry
            }

            val = atof(strng);

            // check that strng holds a number
            int ascii = (int) strng[0]; // ascii value of first character

            if ((ascii < 48) || (ascii > 57)) { // not a digit
                if ((ascii != 45) && (ascii != 46)) { // not a '-' or '.'
                    std::cout << strng << std::endl;
                    fatal("Invalid expression value in input file");
                }
            }

            if ((val > MAX_EXP) || (val < MIN_EXP)) {
                std::cout << val << std::endl;
                fatal("Invalid expression value in input data.  \n\tCheck MAX_EXP and MIN_EXP in header file.");
            }
            
            data[i][j + nCase] = val; // record value
        }
    } // end reading controls data
    
    // check for ends of files
    if (!feof(cases)) {
        fscanf(cases, "%s", strng);
        if (!feof(cases))
            fatal("Unread data in input file");
    }

    fclose(cases);
    
    if (!feof(ctrls)) {
        fscanf(ctrls, "%s", strng);
        if (!feof(ctrls))
            fatal("Unread data in input file");
    }

    fclose(ctrls);  
    
    if (VERBOSE) {
        std::cout << "Analyte labels:\n";
        for (int i = 0; i < numGenes; i++)
          std::cout << labels[i] << "\n";
    
        std::cout << "\nData matrix (cases followed by controls):" << std::endl;
        for (int i = 0; i < numGenes; i++) {
            for (int j = 0; j < nCase + nCtrl; j++)
                std::cout << data[i][j] << " ";
            std::cout << std::endl;
        }
        std::cout << std::endl;
        }
        
    return numMissing;
}

 



// function to compute d2d values for analyte patterns (not single analytes)
void comp_d2d(float **data, char ***labels, int numGenes, int nCase, int nCtrl, int numClusters, int **clusts, int *clustSize, char ***geneHeaderCols, int minNumSubsetCase, int minNumSubsetCtrl, FILE *sigfile, FILE *logfile, FILE *output, int numheadcols) {
    int numMissingCase, numMissingCtrl; // will hold number of missing values in data arrays
    float distCase; // distance between medians for Cases
    float distCtrl; // distance between medians for Controls
    float diffCaseCtrl; // difference between the distances (distCase - distCtrl)
    float pval; // p-value
    float boundaries[2]; // hold the two values bordering the boundary between the 2 clusters
    float thresh; // threshold between clusters (mean between the largest value in cluster 1 and the smallest in cluster 2)
    float youJ; // Youden's J statistic
    float pvalYouJ; // p-value for Youden's J statistic
    float oddsratio[4]; // hold odds ratio and the 95% confidence interval values, plus flag for < or > for the threshold
    int tallies[4]; // tallies of individuals with/without associated expression for each group (case/control)
    float percentCase, percentCtrl; // percentage of each group with associated expression
    bool significant; // flag to mark significant analytes
    char strng[MAX_LABEL_LENGTH+MAX_LABEL_LENGTH]; // temporary string 
    float *caseData, *ctrlData; // hold expression averages for current pattern
    int *isNormalized; // will set to 1 when analyte is normalized
    int numInd = nCase + nCtrl; // total number of individuals
    int analyte; // will hold current analyte index
    int *numMissCase, *numMissCtrl; // will hold number of missing data values
    int finalNumMissCase, finalNumMissCtrl; // will hold number of individuals missing all values in a pattern
//    char sigIndFileName[FILENAMELENGTH]; // hold filename for individuals carrying pattern
//    const char indSuffix[] = ".ind"; // suffix for individuals' filename

        
    // allocate data arrays
    if (((caseData = new float [nCase]) == NULL) || ((ctrlData = new float [nCtrl]) == NULL))
        fatal("memory not allocated");
        
    if ((isNormalized = new int [numGenes]) == NULL)
        fatal("memory not allocated");

    if (((numMissCase = new int [nCase]) == NULL) || ((numMissCtrl = new int [nCtrl]) == NULL))
        fatal("memory not allocated");
        
    for (int i = 0; i < numGenes; i++) { // initialize values accordingly
        if(NORMALIZE)
            isNormalized[i] = 0;
        else
            isNormalized[i] = 1;
    }

    for (int i = 0; i < numClusters; i++) { // *test each pattern*
        for (int j = 0; j < nCase; j++) { // initialize values to zero
            caseData[j] = 0;
            numMissCase[j] = 0;
        }
        for (int j = 0; j < nCtrl; j++) {
            ctrlData[j] = 0;
            numMissCtrl[j] = 0;
        }
        
        finalNumMissCase = finalNumMissCtrl = 0;
            
        for (int j = 0; j < clustSize[i]; j++) { // add values for each analyte in the cluster
            analyte = clusts[i][j];
            
            if(analyte >= numGenes) // this analyte has high expression in the pattern
                analyte -= numGenes; // find actual gene number
    
            if (!isNormalized[analyte]) {
                normalize(data[analyte], numInd, MINVAL, MAXVAL, MAX_EXP+1); //MAX_EXP+1 used to flag missing data
                isNormalized[analyte] = 1; // update status                
            }
            
            if(0) {
                std::cout << "\n\nCases normalized data:  ";
                for (int x = 0; x < nCase; x++)
                    std::cout << data[analyte][x] << "  ";
                std::cout << "\nControls normalized data:  ";
                for (int x = 0; x < nCtrl; x++)
                    std::cout << data[analyte][nCase+x] << "  ";
            }
            
            // for each individual, add analyte value for high expression in pattern
            // add 1 minus analyte value for low expression in pattern
            if(clusts[i][j] >= numGenes) { // high expression
                for (int k = 0; k < nCase; k++) {
                    if(data[analyte][k] < MAX_EXP + TOL) 
                        caseData[k] += data[analyte][k];
                    else
                        numMissCase[k]++;  // another missing data value   
                }
                
                for (int k = 0; k < nCtrl; k++) {
                    if(data[analyte][nCase+k] < MAX_EXP + TOL) // controls are in second part of data array
                        ctrlData[k] += data[analyte][nCase+k];
                    else
                        numMissCtrl[k]++;  // another missing data value                         
                }
            }
            else { // low expression
                for (int k = 0; k < nCase; k++) {
                    if(data[analyte][k] < MAX_EXP + TOL)
                        caseData[k] += 1.0 - data[analyte][k];
                    else
                        numMissCase[k]++;  // another missing data value                         
                }
                
                for (int k = 0; k < nCtrl; k++) {
                    if(data[analyte][nCase+k] < MAX_EXP + TOL) // controls are in second part of data array
                        ctrlData[k] += 1.0 - data[analyte][nCase+k];   
                    else
                        numMissCtrl[k]++;  // another missing data value                         
                }         
            }
        }
        
        if(0) {
            std::cout << "\n**Cases summed data (missing not handled):\t";
            for (int y = 0; y < nCase; y++)
                std::cout << caseData[y] << "  ";
            std::cout << "\n**Controls summed data (missing not handled):\t";
            for (int y = 0; y < nCtrl; y++)
                std::cout << ctrlData[y] << "  ";   
            std::cout << "\n"; 
            std::cout << "\nnumMiss for Cases:\t";
            for (int y = 0; y < nCase; y++)
                std::cout << numMissCase[y] << "  ";
            std::cout << "\nnumMiss for Controls:\t";
            for (int y = 0; y < nCtrl; y++)
                std::cout << numMissCtrl[y] << "  ";   
            std::cout << "\n\n"; 
        }
        
        for (int k = 0; k < nCase; k++) {  // find average value for each case
            if(clustSize[i] - numMissCase[k] > 0 + TOL) // at least one valid value for this individual
                caseData[k] /= (float)(clustSize[i] - numMissCase[k]);
            else
                caseData[k] = MAX_EXP + 1; // mark as missing data
        }
            
        for (int k = 0; k < nCtrl; k++) { // find average value for each control
            if(clustSize[i] - numMissCtrl[k] > 0 + TOL) // at least one valid value for this individual
                ctrlData[k] /= (float)(clustSize[i] - numMissCtrl[k]);
            else
                ctrlData[k] = MAX_EXP + 1; // mark as missing data            
        }
        
        if(0) {
            std::cout << "\n**Cases data average:\t";
            for (int y = 0; y < nCase; y++)
                std::cout << caseData[y] << "  ";
            std::cout << "\n**Controls data average:\t";
            for (int y = 0; y < nCtrl; y++)
                std::cout << ctrlData[y] << "  ";   
            std::cout << "\n"; 
        }
        
        // check that computed values are valid and count individuals with all missing data
        for (int k = 0; k < nCase; k++) {
            if(caseData[k] < MAX_EXP + TOL) { // not a missing value
                if(caseData[k] < 0.0 - TOL)
                    fatal("Invalid average found");
                if(caseData[k] > 1.0 + TOL)
                    fatal("Invalid average found");
            }
            else
                finalNumMissCase++;
        }

        for (int k = 0; k < nCtrl; k++) {
            if(ctrlData[k] < MAX_EXP + TOL) { // not a missing value
                if(ctrlData[k] < 0.0 - TOL)
                    fatal("Invalid average found");
                if(ctrlData[k] > 1.0 + TOL)
                    fatal("Invalid average found");
            }
            else
                finalNumMissCtrl++;
        }
        
        distCtrl = comp2median(ctrlData, minNumSubsetCtrl, nCtrl, finalNumMissCtrl, boundaries);
        if (VERBOSE)
            std::cout << "Distance between medians for Controls is " << distCtrl << ".\n";
        
        distCase = comp2median(caseData, minNumSubsetCase, nCase, finalNumMissCase, boundaries); 
        if (VERBOSE)
            std::cout << "Distance between medians for Cases is " << distCase << ".\n";
            
        diffCaseCtrl = distCase - distCtrl;
        if (VERBOSE)
            std::cout << "Difference in distances is " << diffCaseCtrl << ".\n\n";
        
        // compute threshold and odds ratio
        thresh = comp_odds_ratio(caseData, ctrlData, nCase, nCtrl, finalNumMissCase, finalNumMissCtrl, boundaries, oddsratio, tallies, &youJ);
        percentCase = (float)tallies[0] / (float)(tallies[0] + tallies[1]);
        percentCtrl = (float)tallies[2] / (float)(tallies[2] + tallies[3]);
                
        // compute the p-value    
        pval = comp_pval(caseData, ctrlData, minNumSubsetCase, minNumSubsetCtrl, nCase, nCtrl, finalNumMissCase, finalNumMissCtrl, diffCaseCtrl, thresh, oddsratio[3], youJ, &pvalYouJ);       
        if (VERBOSE) 
            std::cout << "Pattern " << i+1 << " has d2d p-value of " << pval << " and Youden J p-value of " << pvalYouJ << ".\n";
 
        if (SIG_FILE)
            significant = is_significant(pval, oddsratio, pvalYouJ);    
        
        if (SIG_FILE && significant) {
            fprintf(sigfile, "%d\t%d\t", i+1, clustSize[i]); 
            
            if(!USE_YOUJ_SIG)  
            fprintf(sigfile, "%.4f\t", pval); 
             
            if(oddsratio[3] > 0) // high expression
                fprintf(sigfile, ">");
            else if(oddsratio[3] < 0) // low expression
                fprintf(sigfile, "<");
            fprintf(sigfile, "%.3f\t%d(%.1f\%)\t%d(%.1f\%)\t", thresh, tallies[0], percentCase*100, tallies[2], percentCtrl*100);             
            if(oddsratio[0] < 0) // undefined odds ratio
                fprintf(sigfile, "nan(nan,nan) ");
            else
                fprintf(sigfile, "%.3f(%.3f,%.3f) ", oddsratio[0], oddsratio[1], oddsratio[2]);    
            fprintf(sigfile, "%.3f %.5f\n", youJ, pvalYouJ);        
        }
   
        fprintf(output, "Pattern %d with %d analytes\t", i+1, clustSize[i]);   
        
        if(!USE_YOUJ_SIG)                  
            fprintf(output, "pval %.4f\t", pval); 
        
        fprintf(output, "Associated if ");
        
        if(oddsratio[3] > 0) // high expression
            fprintf(output, ">");
        else if(oddsratio[3] < 0) // low expression
            fprintf(output, "<");
        fprintf(output, "%.3f\t%d(%.1f\%) Cases\t%d(%.1f\%) Controls\n\todds ratio: ", thresh, tallies[0], percentCase*100.0, tallies[2], percentCtrl*100.0);             
        if(oddsratio[0] < 0) // undefined odds ratio
            fprintf(output, "nan(nan,nan)\t");
        else
            fprintf(output, "%.3f(%.3f,%.3f)\t", oddsratio[0], oddsratio[1], oddsratio[2]);  
        fprintf(output, "Youden J: %.3f\tYJ pval: %.5f\n\n", youJ, pvalYouJ);  
          
        for (int j = 0; j < clustSize[i]; j++) { // print info for each analyte
            analyte = clusts[i][j];    
            if(analyte >= numGenes) { // this analyte has high expression in the pattern
                analyte -= numGenes; // find actual gene number

                fprintf(output, "\t%d\t", analyte+1); 
                for (int k = 0; k < numheadcols; k++)
                    fprintf(output, "%s\t", geneHeaderCols[analyte][k]); 
                
                fprintf(output, "HIGH\n");  
            } 
            
            else { // this analyte has low expression in the pattern
                fprintf(output, "\t%d\t", analyte+1); 
                for (int k = 0; k < numheadcols; k++)
                    fprintf(output, "%s\t", geneHeaderCols[analyte][k]); 
                
                fprintf(output, "LOW\n");  
            }     
        }  
             
        fprintf(output, "\n");      
                    
    }  // end of testing each pattern
    
/*    
    if (SIG_FILE) {
        sprintf(sigIndFileName, "%s%s", sigFileName, indSuffix); // string together file name for holding lists of individuals
        FILE *indFile; 
        if ((indFile = fopen(sigIndFileName, "w")) == NULL)
            fatal("File for listing individuals could not be opened.\n");
    
        fclose(sigfile); // close file with significant analytes listed
        if ((sigfile = fopen(sigFileName, "r")) == NULL) // reopen file in reading mode
            fatal("File listing significant analytes could not be read.");
            
        rewind(cases); // start reading from the beginning
        rewind(ctrls);
        
        printIndfile(cases, ctrls, sigfile, indFile, nCase, nCtrl, numGenes, numheadrows, numheadcols); 
        fclose(indFile);
        
        if (!QUIET)
          std::cout << "\nIDs listed in row " << IND_ID_ROW << " of the input data files were used to print out individuals with associated expression to '" << sigIndFileName <<"'.\n\n";
    }

    if (SIG_FILE)
        fclose(indFile);
*/

    delete [] caseData;
    delete [] ctrlData;
    delete [] isNormalized;
    delete [] numMissCase;
    delete [] numMissCtrl;
}

















