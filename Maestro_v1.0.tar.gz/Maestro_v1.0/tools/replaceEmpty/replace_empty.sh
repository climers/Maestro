#! /usr/bin/bash
# Script to replace empty entries in tab-separated data with 'NA'
#  and replace spaces with underscores.
# Replace input and output file names with appropriate names (add path 
#  if not in same directory).

inputFile=yourInputFilename
outputFile=yourOutputFilename


sed 's/    /\tNA\t/g' $inputFile >& $outputFile
sed -i 's/  $/\tNA/g' $outputFile
sed -i 's/^  /NA\t/g' $outputFile
sed -i 's/ /_/g' $outputFile
