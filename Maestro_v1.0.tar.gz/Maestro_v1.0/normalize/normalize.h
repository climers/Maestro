// -------------------------------------------------------------------------
// normalize.h
//
// written by Sharlee Climer, August 2024
//
// ------------------------------------------------------------------------

#ifndef _NORMALIZE_H
#define _NORMALIZE_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string.h>

#include "timer.h"

const float IQR_FACTOR = 2.0; // multiply the IQR times this value and use to to subtract/add to Q1/Q3 for winsorizing outliers (2.0 is default)

const int QUIET = 0;  // set to one to eliminate output to screen
const int VERBOSE = 0;  // set to one to display maximum output to screen
const int LOG_FILE = 1; // set to one to print logfile
const int MAXSTRNGLENGTH = 2000; // number of chars in maximum string length

const float TOL = 0.000001; // tolerance
const float MAX_NUM = 1000000; // max value in array (can be modified)

inline void warning(const char* p) { fprintf(stderr,"Warning: %s \n",p); }
inline void fatal(const char* string) {fprintf(stderr,"\nFatal: %s\n\n",string); exit(1); }

#endif
