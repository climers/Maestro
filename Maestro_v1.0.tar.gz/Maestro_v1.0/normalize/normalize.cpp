/*   
 *
 *   normalize.cpp 
 *
 *   Program to normalize a table of values, with each row being normalized 
 *     independently. 
 *   Uses IQR and IQR_FACTOR (defined in normalize.h) to Winsorize outliers
 *   Values are scaled and shifted to desired range
 *
 *   Written by Sharlee Climer
 *   September 2024
 *
 *   v1.2: Added numbers of header rows and columns as command-line arguments. 
 *   Fixed missing data bug.
 *   Sharlee Climer, November 2026
 *
*/

#include "normalize.h"

void checkValidInt(char *strng);
int checkValidFloat(char *strng);
void mergeSort(float *data, int *order, int left, int right);
void merge(float *data, int *order, int left, int mid, int right);
void printFloatArray(float *data, int size);
void printStringArray(char **data, int size);
void printIntArray(int *data, int size);
void clipOutliers(float *data, int size);
void scaleShift(float *data, int size, float minVal, float maxVal);
void normalizeRow(float *data, int numMissRow, int *order, int *indexOrder, int numCols, float minVal, float maxVal);

int main(int argc, char ** argv)
{
  if (argc != 9)
    fatal("Usage:\n  normalize original.txt numDataRowsInput numDataColsInput numHeadRows numHeadCols minTargetVal maxTargetVal output.txt"); 

  timer t;
  t.start("Timer started.");  


  FILE *input; // input file
  FILE *output; // output file
  FILE *logfile; // copy screen output 

  std::cout << "Command line arguments: \n\t";
  for (int i = 0; i < argc; i++)
	std::cout << argv[i] << " ";
  std::cout << "\n" << std::endl;

  // check to be sure all files are available
  if ((input = fopen(argv[1], "r")) == NULL)
    fatal("Input file could not be opened");
  if ((output = fopen(argv[8], "w")) == NULL)
    fatal("Output file could not be opened.\n");
    
  // check that command line values are integers  
  checkValidInt(argv[2]); 
  checkValidInt(argv[3]); 
  
  if ((checkValidFloat(argv[6]) == 1) || (checkValidFloat(argv[7]) == 1))
    fatal("Invalid minVal or maxVal."); 
  
  int numRows = atoi(argv[2]); // number of rows in input file
  int numCols = atoi(argv[3]); // number of columns in input file
  int numHeadRows = atoi(argv[4]); // number of header rows
  int numHeadCols = atoi(argv[5]); // number of header columns
  float minVal = atof(argv[6]); // minimum value after normalization
  float maxVal = atof(argv[7]); // maximum value after normalization
  char logfileName[MAXSTRNGLENGTH+4]; // will hold logfile name (added 4 chars for suffix)
  char strng[MAXSTRNGLENGTH]; // temporary storage of strings
  int numMissing = 0; // record number of missing values
  int numMissRow; // number missing in each row

  if (!QUIET) 
    std::cout << "Assuming input file '" << argv[1] << "' has " << numHeadRows << " header rows, " << numRows << " data rows, " << numHeadCols << " header columns, and " << numCols << " data columns.\n\t(Numbers of headers can be changed in 'normalize.h'.)\nEach row will be independently normalized.\nOutliers will be winsorized using interquartile range and a factor of " << IQR_FACTOR << " (specified in 'normalize.h').\nValues will then be scaled and shifted to range from " << minVal << " to " << maxVal << ".\nAssumed missing data values begin with 'N'.\n\n";
  
    char base[MAXSTRNGLENGTH]; // base for supplemental file names
    const char logSuffix[] = ".log"; // suffix for logfile name

    // determine name for log file
    for (int i = 0; i < 400; i++) {
        base[i] = argv[8][i]; // copy output file name
        if (base[i] == '\0') {
            if (i < 2)
                fatal("Expected output file name to have at least two characters");

            base[i] = '\0'; // set end of string
            
            if(base[i-4] == '.') // remove suffix (if exists) before adding .log suffix
                base[i-4] = '\0';
            break;
        }
    }

    sprintf(logfileName, "%s%s", base, logSuffix); // string together file name for logfile name

    if (LOG_FILE && !QUIET)
        std::cout << "Summary output will be recorded in '" << logfileName << "'.\n" << std::endl;

    if ((logfile = fopen(logfileName, "w")) == NULL)
        fatal("Log file could not be opened.\n");
        
    if (LOG_FILE) {
        fprintf(logfile, "Command line arguments: \n\t");
        for (int i = 0; i < argc; i++)
            fprintf(logfile, "%s ", argv[i]);
        fprintf(logfile, "\n\nAssuming input file '%s' has %d header rows, %d data rows, %d header columns, and %d data columns.\nEach row will be independently normalized.\nOutliers will be winsorized using interquartile range and IQR_FACTOR of %f.\nValues will then be scaled and shifted to range from %f to %f.\nAssumed missing data values begin with 'N'.\n\n", argv[1], numHeadRows, numRows, numHeadCols, numCols, IQR_FACTOR, minVal, maxVal);
    }

  // allocate memory for copy of data values, will hold normalized values
  float *data;
  if((data = new float[numCols]) == NULL)
    fatal("memory not allocated");  

  float *origData;
  if((origData = new float[numCols]) == NULL)
    fatal("memory not allocated");  
 
  // allocate memory for array to hold ordering of the values
  int *order;
  if((order = new int[numCols]) == NULL)
    fatal("memory not allocated");   
    
  // allocate memory for array to hold index of ordering
  int *indexOrder;
  if((indexOrder = new int[numCols]) == NULL)
    fatal("memory not allocated");   
    
  // read in and print out header rows
  for (int i = 0; i < numHeadRows; i++) {
    for (int j = 0; j < numHeadCols + numCols; j++) {
      fscanf (input, "%s", strng);
      fprintf (output, "%s\t", strng);
    }
    fprintf(output, "\n");
  }

  // read in each data row, normalize, and write out
  for (int i = 0; i < numRows; i++) {
    numMissRow = 0; // initialize count of missing values
    // read in and write out header columns
    for (int j = 0; j < numHeadCols; j++) {
      fscanf (input, "%s", strng);
      fprintf (output, "%s\t", strng);
    }
    
    // read in data for the row
    for (int j = 0; j < numCols; j++) {
      if(feof(input))
	      fatal("Input file is missing data");
      fscanf (input, "%s", strng);
      
      if (checkValidFloat(strng) == 1) { // check to be sure float (or int) value is valid
        numMissRow++;
        origData[j] = data[j] = MAX_NUM + 1; // set to infinity        
      }
      else 
        origData[j] = data[j] = atof(strng);  
    }
      
    // normalize and print out data 
    normalizeRow(data, numMissRow, order, indexOrder, numCols, minVal, maxVal);
    numMissing += numMissRow; // add additional missing for this row
    
    // print out normalized data using original ordering
    for (int i = 0; i < numCols; i++) {
      if (data[indexOrder[i]] > MAX_NUM)  // missing data
        fprintf(output, "NA\t");
      else
        fprintf(output, "%f\t", data[indexOrder[i]]);
    }
    fprintf(output, "\n");
  }
  
  if (!QUIET)
    std::cout << numMissing << " missing values in input file.\n";
    
  if (LOG_FILE)
    fprintf(logfile, "%d missing values in input file.\n\n", numMissing);
 
  // check for end of file
  if (!feof(input)){
    fscanf(input, "%s", strng);
    if (!feof(input))
      fatal("Unread data in input file");
  }
  
  if (!QUIET)
    std::cout << "Normalized data has been written to '" << argv[8] << "'.\n" << std::endl;

  fclose(input);
  fclose(output);
  
//  for (int i = 0; i < numCols; i++)
//    delete [] ids[i];
    
//  delete [] ids;
  delete [] order;
  delete [] indexOrder;
  delete [] data;
  delete [] origData;
  
  t.stop("Timer stopped");
  std::cout << t << " seconds\n" << std::endl;
  
  if (LOG_FILE) 
    fprintf(logfile, "%f seconds computation time.\n", t);
  fclose(logfile);
    
  return 1;
}



void checkValidInt(char *strng) {  // checks string to see if it starts with a valid character for an int
    int ascii;
    int digit = 0;

    while (strng[digit] != '\0') { // check each digit
        ascii = (int) strng[digit]; // ascii value of next character
        if ((ascii < 48) || (ascii > 57)) { // not a digit
            if ((digit != 0) && (ascii == 45)) { // not a '-' at the beginning     
                std::cout << strng << std::endl;
                fatal("Invalid input value. Expected an integer.");
            }
        }
        digit++;
    }
    
    int temp = atoi(strng);
    if (temp > MAX_NUM)
        fatal("Input value exceeds MAX_NUM. (MAXNUM can be changed in 'normalize.h'.");
}


int checkValidFloat(char *strng) {  // checks string to see if it starts with a valid character for a float
    int ascii;
    int digit = 0;

    if (strncmp(strng, "N", 1) == 0)  // missing data
        return 1;

    while (strng[digit] != '\0') { // check each digit
        ascii = (int) strng[digit]; // ascii value of next character
        if ((ascii < 48) || (ascii > 57)) { // not a digit
          if (ascii != 46) { // not a '.' (multiple decimal points could get by this check)
            if (ascii != 45) { // not a '-' (dash in middle would get by this check)
            if ((ascii != 101) && (ascii != 69)) { // not an 'e' or 'E'
                    if (ascii != 43) { // not a '+'
                        std::cout << strng << std::endl;
                        fatal("checkValidFloat function identified an invalid expression value in input file");
                    }
                }
            }       
          }
        }
        digit++;
    }
    
    float temp = atof(strng);
    if (temp > MAX_NUM)
        fatal("Input value exceeds MAX_NUM. (MAXNUM can be changed in 'normalize.h'.");
        
    return 0;
}


void mergeSort(float *data, int *order, int left, int right) { // use mergesort to sort values (preserve original mapping in order array)
    if (left < right) { // left and right are the indices of the subportion of the array 
        int mid = (left + right) / 2;
        mergeSort(data, order, left, mid); // recursively split left side
        mergeSort(data, order, mid+1, right); // recursively split right side
        
        merge(data, order, left, mid, right); // merge sorted arrays together
    }
}



void merge(float *data, int *order, int left, int mid, int right) {
    int i, j; // loop counters, then index pointers
    int n1 = mid - left + 1; // size of left subarray
    int n2 = right - mid; // size of right subarray
    
    float *leftArray, *rightArray; // create subarrays
    if(((leftArray = new float[n1+2]) == NULL) || ((rightArray = new float[n2+2]) == NULL))
        fatal("memory not allocated");   
        
    int *leftOrder, *rightOrder; // create subarrays for copying order values
    if(((leftOrder = new int[n1+2]) == NULL) || ((rightOrder = new int[n2+2]) == NULL))
        fatal("memory not allocated");   
    
    // copy data to temp arrays    
    for (i = 1; i <= n1; i++) {
        leftArray[i] = data[left + i - 1];   
        leftOrder[i] = order[left + i - 1];
    }
        
    for (j = 1; j <= n2; j++) {
        rightArray[j] = data[mid + j];
        rightOrder[j] = order[mid + j];
    }
            
    leftArray[n1 + 1] = rightArray[n2 + 1] = MAX_NUM + 100.0; // set to infinity
        
    // merge the temp arrays and overwrite the original array
    i = 1; // initialization of subarray pointers
    j = 1; 
    
    for (int k = left; k <= right; k++) {
        if (leftArray[i] <= rightArray[j]) {
            data[k] = leftArray[i];
            order[k] = leftOrder[i];
            i++;
        }
        else {
            data[k] = rightArray[j];
            order[k] = rightOrder[j];
            j++;
        }
    }

    delete [] leftArray;
    delete [] rightArray;
    delete [] leftOrder;
    delete [] rightOrder;
}



void printFloatArray(float *data, int size) {  // print array of floats
    for (int i = 0; i < size; i++)
        std::cout << "\t" << data[i];
    std::cout << "\n";
}

void printStringArray(char **data, int size) {  // print array of strings
    for (int i = 0; i < size; i++)
        std::cout << "\t" << data[i];
    std::cout << "\n";
}

void printIntArray(int *data, int size) {  // print array of ints
    for (int i = 0; i < size; i++)
        std::cout << "\t" << data[i];
    std::cout << "\n";
}


void clipOutliers(float *data, int size) { // wonsorize outliers using IQR and IQR_FACTOR ***assumed data is pre-sorted in ascending order***    
    float median; // median (Q2)
    int halfSize; // floor of half the size of the array
    float q1, q3; // lower (Q1) and upper (Q3) quartile values 
    int halfLeft; // floor of halfway point in left half of array
    int halfRight; // floor of halfway point in right half of array
    float iqr; // interquartile range (IQR)
    float lowestVal, highestVal; // lowest and highest values after winsorizing outliers
    int ptr; // pointer for traversing array
    
    // determine median
    halfSize = size/2; // halfway point in data or value just below half if even number of values
    if (size % 2 == 0) // even number of data points
        median = (data[halfSize - 1] + data[halfSize]) / 2.0; // take average of the two flanking values
    else // odd number of data points
        median = data[halfSize];    
    
    // determine lower (Q1) quartile value
    halfLeft = halfSize/2; // halfway point in left half of data or value just below half if even number of values
    if (halfSize % 2 == 0) // even number of data points
        q1 = (data[halfLeft - 1] + data[halfLeft]) / 2.0; // take average of the two flanking values
    else // odd number of data points
        q1 = data[halfLeft]; 

    // determine upper (Q3) quartile value
    halfRight = (size - halfSize) / 2; // halfway point in left half of data or value just below half if even number of values
    if ((size - halfSize) % 2 == 0) // even number of data points
        q3 = (data[halfSize + halfRight - 1] + data[halfSize + halfRight]) / 2.0; // take average of the two flanking values
    else // odd number of data points
        q3 = data[halfSize + halfRight]; 
        
    // determine interquartile range (IQR)
    iqr = q3 - q1;
        
    // find lowest and highest allowed values
    lowestVal = q1 - (iqr * IQR_FACTOR); 
    highestVal = q3 + (iqr * IQR_FACTOR); 
    
    if (VERBOSE)
        std::cout << "Winsorizing outliers: \n\tValues less than Q1 - (IQR * " << IQR_FACTOR << ") = " << lowestVal << " will be replaced by that minimum value \n\tValues greater than Q3 + (IQR * " << IQR_FACTOR << ") = " << highestVal << " will be replaced by that maximum value\n\n";

    if (VERBOSE) 
      std::cout << "Median = " << median << ", Q1 = " << q1 << ", Q3 = " << q3 << ", IQR = " << iqr << ", lowest allowed value = " << lowestVal << ", highest allowed = " << highestVal << ".\n\n";
    
    // winsorize outliers
    ptr = 0;
    while (data[ptr] < lowestVal) 
        data[ptr++] = lowestVal;
        
    ptr = size - 1;
    while (data[ptr] > highestVal) 
        data[ptr--] = highestVal;
}


void scaleShift(float *data, int size, float minVal, float maxVal) { // scale and shift values to specified range. Assumed data is sorted.
    float oldMin = data[0]; // minimum value in data array
    float oldMax = data[size-1]; // maximum value in data array
    
    for (int i = 0; i < size; i++) 
        data[i] = ((data[i] - oldMin) * (maxVal - minVal) / (oldMax - oldMin)) + minVal;
    
    if (VERBOSE) {
        std::cout << "Scaled and shifted values:\n";
        printFloatArray(data, size);
    }
    
}


void normalizeRow(float *data, int numMissRow, int *order, int *indexOrder, int numCols, float minVal, float maxVal) {
 
   // initialize order array (numbers will be sorted along with corresponding values)
  for (int i = 0; i < numCols; i++)
    order[i] = i;
    
  if (VERBOSE) {
    std::cout << "\nInput values:\n";
    printFloatArray(data, numCols);
  }

  //sort data values while preserving original order with mapping in order array
  mergeSort(data, order, 0, numCols-1); 

  // translate ordering to direct indices 
  for (int i = 0; i < numCols; i++)
    indexOrder[order[i]] = i; 

  if (VERBOSE) {
    std::cout << "\nSorted values:\n";
    printFloatArray(data, numCols);
    std::cout << "\nOrdering of values:\n";
    printIntArray(order, numCols);
    std::cout << "\nIndexOrdering:\n";
    printIntArray(indexOrder, numCols);
  }

  clipOutliers(data, numCols - numMissRow); // winsorize outliers using IQR and IQR_FACTOR
      
    if (VERBOSE) {
        std::cout << "Sorted and winsorized array:\n";
        printFloatArray(data, numCols); 
    }
 
  scaleShift(data, numCols - numMissRow, minVal, maxVal); // scale and shift values to specified range
}

































